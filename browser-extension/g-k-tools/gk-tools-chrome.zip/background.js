// Background script: builds the right-click context menus (kintone / Markdown).
// Runs as a service worker (Chrome) or an event-page script (Firefox), so it is
// a self-contained classic script — no ES `import` (the two runtimes disagree on
// module backgrounds). The page-injected function below is likewise standalone.

const api = globalThis.browser ?? globalThis.chrome;

// Flat top-level context-menu items — NO submenus/parents. Each is gated so
// that at most one is visible in any given context; that is what keeps Firefox
// from collapsing them under a single "GK Tools" parent (it wraps only when 2+
// items are visible at once). The copy items use PAGE_CTX (every context EXCEPT
// "link") and the Markdown item uses "link" — so they never appear together,
// even when right-clicking a .md link on a kintone/Garoon page.
const PAGE_CTX = ["page", "selection", "editable", "image"];
const MENUS = [
    {
        id: "copyPBI",
        title: "GK Tools - Copy PBI Contents",
        contexts: PAGE_CTX,
        urlPattern: /^https:\/\/bozuman\.cybozu\.com\/k\/\d+/, // kintone app tabs
    },
    {
        id: "copyScheduleComment",
        title: "GK Tools - Copy Schedule comment",
        contexts: PAGE_CTX,
        urlPattern: /\/(g|grn\.cgi)\/schedule\/view\.csp/i, // Garoon event detail
    },
    {
        id: "copyScheduleSprint",
        title: "GK Tools - Copy Schedule Sprint",
        contexts: PAGE_CTX,
        urlPattern: /\/(g|grn\.cgi)\/(index|portal\/index)/i, // Garoon top page / portal
    },
    {
        id: "gitMdViewer",
        title: "GK Tools - Git Markdown Viewer",
        contexts: PAGE_CTX,
        // GitHub PR diff pages only ("Files changed" — new /changes UI or old /files)
        urlPattern: /^https:\/\/github\.com\/[^/]+\/[^/]+\/pull\/\d+\/(changes|files)([/?#]|$)/,
        // Extra in-page condition: show only when the PR actually changes a .md file.
        pageCheck: "mdInPr",
    },
    {
        // Page-context twin of "openMarkdownViewer": right-click anywhere and pick
        // from the page's doc list. Needed because a file name in a GitHub repo
        // tree or PR diff is not always an <a> whose href ends in ".md", so the
        // link-context item cannot appear there at all.
        id: "openMarkdownViewerList",
        title: "GK Tools - Markdown Text Viewer (pick a file…)",
        contexts: PAGE_CTX,
        urlPattern: /^https:\/\/(github\.com|bozuman\.cybozu\.com)\//,
        pageCheck: "docsOnPage",
    },
    {
        id: "openMarkdownViewer",
        title: "GK Tools - Markdown Text Viewer",
        contexts: ["link"], // only on links to a .md / .markdown / .txt file
        // Match patterns are compared against path + query and NEVER against the
        // fragment, so a "…#*" pattern is invalid — and one invalid entry makes
        // contextMenus.create reject the WHOLE item, which is why this used to
        // vanish everywhere. Dropping them loses nothing: "a.md#L5" is matched
        // as "/a.md" and hits the plain pattern.
        targetUrlPatterns: [
            "*://*/*.md", "*://*/*.markdown", "*://*/*.txt",
            "*://*/*.md?*", "*://*/*.markdown?*", "*://*/*.txt?*",
            "file:///*.md", "file:///*.markdown", "file:///*.txt",
            // File names in a PR (diff header and left file tree) link to
            // "…/pull/<n>/changes#diff-<sha256 of the path>", not to the file.
            // Accept those too and resolve them on click.
            "*://github.com/*/pull/*",
        ],
    },
];

// Attach a no-op catch when a call returns a promise (Firefox / Chrome MV3),
// and stay silent when it returns undefined (chrome.* callback style).
function ignore(maybePromise) {
    if (maybePromise && typeof maybePromise.catch === "function") maybePromise.catch(() => {});
}

function buildMenus() {
    api.contextMenus.removeAll(() => {
        void api.runtime.lastError; // clear any pending error
        for (const m of MENUS) {
            const children = m.children || [];
            const gated = m.urlPattern || children.some((c) => c.urlPattern);

            const top = {
                id: m.id,
                title: m.title,
                contexts: m.contexts || ["all"],
            };
            if (gated) top.visible = false; // toggled by tab URL
            if (m.targetUrlPatterns) top.targetUrlPatterns = m.targetUrlPatterns;
            // Never let a rejected item fail silently: a single bad
            // targetUrlPattern drops the whole entry, and the only symptom is a
            // menu item that never appears anywhere.
            api.contextMenus.create(top, () => {
                const err = api.runtime.lastError;
                if (err) console.error("[GK Tools] context menu '" + m.id + "' was rejected:", err.message || err);
            });

            for (const c of children) {
                const child = {
                    id: c.id,
                    parentId: m.id,
                    title: c.title,
                    contexts: c.contexts || m.contexts || ["all"],
                };
                if (c.urlPattern) child.visible = false;
                if (c.targetUrlPatterns) child.targetUrlPatterns = c.targetUrlPatterns;
                api.contextMenus.create(child);
            }
        }
        // Sync against whatever tab is already active (e.g. right after the
        // extension is reloaded on an already-open kintone tab).
        syncActiveTab();
    });
}

api.runtime.onInstalled.addListener(buildMenus);
api.runtime.onStartup && api.runtime.onStartup.addListener(buildMenus);

// Show URL-gated menus only on matching pages. Keyed on the TAB's top-level URL
// (unaffected by iframes). Entries gate the whole item; url-gated children are
// toggled individually and their parent shows when any child is visible.
function syncVisibility(url, tabId) {
    const u = url || "";
    for (const m of MENUS) {
        const children = m.children || [];
        if (children.some((c) => c.urlPattern)) {
            let anyVisible = false;
            for (const c of children) {
                if (!c.urlPattern) { anyVisible = true; continue; }
                const vis = c.urlPattern.test(u);
                ignore(api.contextMenus.update(c.id, { visible: vis }));
                if (vis) anyVisible = true;
            }
            ignore(api.contextMenus.update(m.id, { visible: anyVisible }));
        } else if (m.urlPattern) {
            const vis = m.urlPattern.test(u);
            if (vis && m.pageCheck === "docsOnPage" && tabId != null) {
                // Show only when the page actually links to a doc worth opening.
                ignore(api.contextMenus.update(m.id, { visible: false }));
                collectLinksInTab(tabId).then((links) => {
                    ignore(api.contextMenus.update(m.id, { visible: links.length > 0 }));
                });
            } else if (vis && m.pageCheck === "mdInPr" && tabId != null) {
                // URL matches — refine with the .md check. The content script
                // (tools/gk-pr-button.js) usually reported the count already;
                // fall back to an on-demand in-page scan when it has not
                // (e.g. the extension was just (re)loaded on an open tab).
                const cached = mdCounts[tabId];
                if (cached != null) {
                    ignore(api.contextMenus.update(m.id, { visible: cached > 0 }));
                } else {
                    ignore(api.contextMenus.update(m.id, { visible: false }));
                    Promise.resolve(
                        api.scripting.executeScript({ target: { tabId }, func: detectMdInPr })
                    ).then((results) => {
                        const found = results && results[0] && results[0].result;
                        ignore(api.contextMenus.update(m.id, { visible: !!found }));
                    }).catch(() => {});
                }
            } else {
                ignore(api.contextMenus.update(m.id, { visible: vis }));
            }
        }
    }
}

// --- .md count per tab: reported by tools/gk-pr-button.js, drives the
// Git Markdown Viewer menu visibility.
const mdCounts = {};

api.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    // The Markdown Text Viewer picked another file from the page's list: fetch it
    // in the SOURCE tab's origin (cookies, no CORS) and send the text back. Falls
    // back to a background fetch when that tab is gone.
    if (msg && msg.type === "gkFetchDoc") {
        const srcTab = msg.tabId;
        const inPage = srcTab != null
            ? fetchDocInTab(srcTab, msg.url)
            : Promise.resolve({ ok: false });
        inPage.catch(() => ({ ok: false }))
            .then((r) => (r && r.ok ? r : fetchDocHere(msg.url)))
            .catch((e) => ({ ok: false, error: String((e && e.message) || e) }))
            .then(sendResponse);
        return true; // async response
    }

    const tabId = sender && sender.tab && sender.tab.id;
    if (tabId == null || !msg) return;
    if (msg.type === "gkMdCount") {
        mdCounts[tabId] = msg.count | 0;
        if (sender.tab.active) syncVisibility(sender.tab.url, tabId);
    } else if (msg.type === "gkRunGitMdViewer") {
        // Floating button clicked: inject the viewer (shared libs first).
        ignore(api.scripting.executeScript({
            target: { tabId },
            files: ["shared/markdown.js", "shared/spinner.js", "tools/git-md-viewer.js"],
        }));
    }
});

api.tabs.onRemoved.addListener((tabId) => { delete mdCounts[tabId]; });

function syncActiveTab() {
    ignore(
        Promise.resolve(api.tabs.query({ active: true, lastFocusedWindow: true })).then((tabs) => {
            const tab = tabs && tabs[0];
            syncVisibility(tab && tab.url, tab && tab.id);
        })
    );
}

api.tabs.onActivated.addListener(({ tabId }) => {
    ignore(Promise.resolve(api.tabs.get(tabId)).then((tab) => syncVisibility(tab && tab.url, tabId)));
});
api.tabs.onUpdated.addListener((tabId, info, tab) => {
    // Only the active tab drives the (global) menu visibility — ignore updates
    // to background tabs, which would otherwise flip the menu incorrectly.
    if (tab && tab.active && (info.url || info.status === "complete")) syncVisibility(tab.url, tabId);
});
api.windows && api.windows.onFocusChanged && api.windows.onFocusChanged.addListener(() => syncActiveTab());
// GitHub is a SPA: switching to the "Files changed" tab is a history.pushState
// soft-navigation (no reload), which tabs.onUpdated does not reliably report.
// webNavigation.onHistoryStateUpdated is the event made for exactly that.
api.webNavigation && api.webNavigation.onHistoryStateUpdated.addListener(({ tabId, url, frameId }) => {
    if (frameId !== 0) return; // top frame only
    ignore(Promise.resolve(api.tabs.get(tabId)).then((tab) => {
        if (tab && tab.active) syncVisibility(url || tab.url, tabId);
    }));
});

// Copy actions share the scraper FILES with the popup (they self-register on
// globalThis.GKScrape): inject the file first, then a small runner that calls
// the scraper and copies/toasts in the page. Same isolated world → the global
// defined by the first call is visible to the second.
const COPY_ACTIONS = {
    copyPBI: { file: "kintone/copyPBIRecords.js", fn: "scrapePBIRecords", args: ["Key,Summary"], noun: "rows" },
    copyScheduleComment: { file: "garoon/scrapeScheduleComments.js", fn: "scrapeScheduleComments", args: [], noun: "comments" },
    copyScheduleSprint: { file: "garoon/scrapeScheduleSprint.js", fn: "scrapeScheduleSprint", args: [], noun: "events" },
};

// Route clicks to the matching action.
api.contextMenus.onClicked.addListener((info, tab) => {
    const copyAction = COPY_ACTIONS[info.menuItemId];
    if (copyAction) {
        if (tab && tab.id) {
            ignore(
                Promise.resolve(api.scripting.executeScript({
                    target: { tabId: tab.id },
                    files: [copyAction.file],
                })).then(() => api.scripting.executeScript({
                    target: { tabId: tab.id },
                    func: runScraperAndCopy,
                    args: [copyAction.fn, copyAction.args, copyAction.noun],
                }))
            );
        }
        return;
    }
    switch (info.menuItemId) {
        case "gitMdViewer":
            // Inject the full viewer as a content-script file: exempt from the
            // page CSP (unlike a bookmarklet) and fetches with the page cookies.
            if (tab && tab.id) {
                ignore(api.scripting.executeScript({
                    target: { tabId: tab.id },
                    // Order matters: shared libs define GKMD/GKSpin before the tool runs.
                    files: ["shared/markdown.js", "shared/spinner.js", "tools/git-md-viewer.js"],
                }));
            }
            break;
        case "openMarkdownViewerList": {
            // No file chosen yet: hand over the page's doc list and let the
            // viewer's picker do the choosing (same payload shape as the popup).
            if (!tab || !tab.id) break;
            const viewerUrl = api.runtime.getURL("tools/md-viewer.html");
            collectLinksInTab(tab.id).then((links) => {
                if (!links.length) return ignore(api.tabs.create({ url: viewerUrl }));
                return Promise.resolve(api.storage.local.set({
                    gkMdPayload: { links, tabId: tab.id },
                })).then(() => ignore(api.tabs.create({ url: viewerUrl + "?src=local" })));
            }).catch(() => ignore(api.tabs.create({ url: viewerUrl })));
            break;
        }
        case "openMarkdownViewer": {
            const link = info.linkUrl;
            const viewer = api.runtime.getURL("tools/md-viewer.html");
            const openWithUrlParam = () =>
                ignore(api.tabs.create({ url: viewer + "?md=" + encodeURIComponent(link || "") }));

            if (!link || !tab || !tab.id) {
                ignore(api.tabs.create({ url: viewer }));
                break;
            }
            // A PR file link is "…/changes#diff-<hash>", which is the page
            // itself — resolve it to the file's blob URL first (see
            // shared/doclinks.js). Anything already file-shaped passes straight
            // through.
            const resolveThenOpen = (realLink) => Promise.all([
                fetchDocInTab(tab.id, realLink),
                collectLinksInTab(tab.id),
            ]).then(([r, links]) => {
                if (!r || !r.ok) return openWithUrlParam();
                return Promise.resolve(api.storage.local.set({
                    gkMdPayload: { text: r.text, source: realLink, name: r.name || null, links, tabId: tab.id },
                })).then(() => ignore(api.tabs.create({ url: viewer + "?src=local" })));
            });

            if (!/\.(md|markdown|txt|text|log)(?:[?#]|$)/i.test(link)) {
                Promise.resolve(
                    api.scripting.executeScript({ target: { tabId: tab.id }, files: ["shared/doclinks.js"] })
                ).then(() => api.scripting.executeScript({
                    target: { tabId: tab.id },
                    func: (u) => globalThis.GKScrape.resolveDiffAnchor(u),
                    args: [link],
                })).then((res) => {
                    const resolved = res && res[0] && res[0].result;
                    // Could not tell which file: fall back to the picker list.
                    if (!resolved) {
                        return collectLinksInTab(tab.id).then((links) => {
                            if (!links.length) return openWithUrlParam();
                            return Promise.resolve(api.storage.local.set({
                                gkMdPayload: { links, tabId: tab.id },
                            })).then(() => ignore(api.tabs.create({ url: viewer + "?src=local" })));
                        });
                    }
                    return resolveThenOpen(resolved);
                }).catch(openWithUrlParam);
                break;
            }

            // Fetch the .md in the clicked page's own origin (authenticated
            // cookies, no CORS — works for private GitHub repos), then hand the
            // text to the viewer via storage. Alongside it, collect every other
            // doc link on that page so the viewer can offer a file picker; the
            // source tabId lets the viewer fetch those in the same origin too.
            // Fall back to letting the viewer fetch the URL itself on failure.
            Promise.all([
                fetchDocInTab(tab.id, link),
                collectLinksInTab(tab.id),
            ]).then(([r, links]) => {
                if (!r || !r.ok) return openWithUrlParam();
                return Promise.resolve(api.storage.local.set({
                    gkMdPayload: { text: r.text, source: link, name: r.name || null, links, tabId: tab.id },
                })).then(() => ignore(api.tabs.create({ url: viewer + "?src=local" })));
            }).catch(openWithUrlParam);
            break;
        }
    }
});

// Collect the page's doc links by injecting the SAME shared scraper file the
// popup uses, then a tiny runner that calls it. Never rejects — an empty list
// just means the viewer shows no picker.
function collectLinksInTab(tabId) {
    return Promise.resolve(
        api.scripting.executeScript({ target: { tabId }, files: ["shared/doclinks.js"] })
    ).then(() => api.scripting.executeScript({
        target: { tabId },
        func: () => globalThis.GKScrape.collectDocLinks(),
    })).then((res) => {
        const r = res && res[0] && res[0].result;
        return (r && r.links) || [];
    }).catch(() => []);
}

// Fetch a document in the page's own origin via shared/docfetch.js, which also
// turns a GitHub "blob" HTML page into the file's real text.
function fetchDocInTab(tabId, url) {
    return Promise.resolve(
        api.scripting.executeScript({ target: { tabId }, files: ["shared/docfetch.js"] })
    ).then(() => api.scripting.executeScript({
        target: { tabId },
        func: (u) => globalThis.GKScrape.fetchDocInPage(u),
        args: [url],
    })).then((res) => (res && res[0] && res[0].result) || { ok: false });
}

// --- Injected into the page (context-menu copy runner) ---------------------
// Runs AFTER the scraper file was injected into the same isolated world (see
// COPY_ACTIONS): calls globalThis.GKScrape[fnName], then copies + toasts here
// in the page (focused by the context-menu click, so execCommand('copy') works;
// the popup path instead copies from the popup itself).
function runScraperAndCopy(fnName, args, noun) {
    function toast(msg, ok) {
        const t = document.createElement("div");
        t.textContent = msg;
        Object.assign(t.style, {
            position: "fixed", zIndex: 2147483647, left: "50%", bottom: "24px",
            transform: "translateX(-50%)", padding: "10px 16px", borderRadius: "8px",
            font: "13px -apple-system, sans-serif", color: "#fff",
            background: ok ? "#059669" : "#dc2626", boxShadow: "0 4px 12px rgba(0,0,0,.25)",
        });
        document.body.appendChild(t);
        setTimeout(() => t.remove(), 2200);
    }
    function copyText(text) {
        const ta = document.createElement("textarea");
        ta.value = text;
        ta.style.position = "fixed";
        ta.style.top = "-9999px";
        document.body.appendChild(ta);
        ta.focus();
        ta.select();
        let ok = false;
        try { ok = document.execCommand("copy"); } catch (e) { ok = false; }
        ta.remove();
        return ok;
    }

    const scraper = globalThis.GKScrape && globalThis.GKScrape[fnName];
    if (!scraper) { toast("Scraper not loaded (" + fnName + ").", false); return; }
    const r = scraper.apply(null, args || []);
    if (!r || !r.ok) { toast((r && r.error) || "Could not read data.", false); return; }
    const ok = copyText(r.text);
    const n = r.rows != null ? r.rows : r.count;
    toast(ok ? "Copied " + (n != null ? n + " " + noun + " " : "") + "\u2713" : "Copy failed", ok);
}


// --- Injected into a GitHub PR "Files changed" page (menu visibility check) --
// Returns true when the PR diff on this page includes a changed .md file.
// Mirrors the path scan of tools/git-md-viewer.js (embedded React JSON + DOM).
// GitHub is a SPA: after a soft-navigation onto /changes the embedded JSON in
// the live document still belongs to the PREVIOUS route, so when the static
// scans find nothing this fetches the canonical /changes page (same-origin,
// with cookies) and scans THAT — reliable regardless of render timing.
async function detectMdInPr() {
    const reMd = /\.(md|markdown)$/i;

    function scanDoc(root) {
        for (const s of root.querySelectorAll('script[type="application/json"]')) {
            // Cheap pre-filter before parsing multi-MB payloads.
            if (!/\.(md|markdown)"/i.test(s.textContent)) continue;
            let j;
            try { j = JSON.parse(s.textContent); } catch (e) { continue; }
            let found = false;
            (function walk(o) {
                if (found || !o || typeof o !== "object") return;
                for (const k in o) {
                    const v = o[k];
                    // The key name is a strong signal here, so a root-level
                    // "README.md" (no slash) counts too.
                    if ((k === "path" || k === "filePath" || k === "newPath" || k === "oldPath") &&
                        typeof v === "string" && reMd.test(v)) { found = true; return; }
                    walk(v);
                }
            })(j);
            if (found) return true;
        }
        return false;
    }

    try {
        if (scanDoc(document)) return true;
        // DOM fallback: attribute values are noisier, so require a path-like "/".
        for (const e of document.querySelectorAll("[data-path],[data-file-path],[data-tagsearch-path],[title]")) {
            const t = e.getAttribute("data-path") || e.getAttribute("data-file-path") ||
                      e.getAttribute("data-tagsearch-path") || e.getAttribute("title") || "";
            if (t.includes("/") && reMd.test(t)) return true;
        }
        // Soft-navigation fallback: fetch the canonical full-diff page fresh.
        const m = location.pathname.match(/^\/([^/]+)\/([^/]+)\/pull\/(\d+)/);
        if (m) {
            const res = await fetch(`/${m[1]}/${m[2]}/pull/${m[3]}/changes`, { credentials: "include" });
            if (res.ok) {
                const doc = new DOMParser().parseFromString(await res.text(), "text/html");
                if (scanDoc(doc)) return true;
            }
        }
    } catch (e) {}
    return false;
}

// --- Last-resort fetch from the background itself ---------------------------
// Used only when the source tab is gone, so the page-origin fetch (and its
// cookies) is unavailable. Mirrors shared/docfetch.js for the GitHub blob case
// so a picked file still resolves to text rather than an HTML page.
async function fetchDocHere(url) {
    const pullRawLines = (html) => {
        let found = null;
        try {
            const doc = new DOMParser().parseFromString(html, "text/html");
            for (const s of doc.querySelectorAll('script[type="application/json"]')) {
                let j;
                try { j = JSON.parse(s.textContent); } catch (e) { continue; }
                (function walk(o) {
                    if (found || !o || typeof o !== "object") return;
                    if (Array.isArray(o.rawLines) && o.rawLines.every((x) => typeof x === "string")) { found = o.rawLines; return; }
                    for (const k in o) walk(o[k]);
                })(j);
                if (found) break;
            }
        } catch (e) {}
        return found ? found.join("\n") : null;
    };
    try {
        const isBlob = /^https:\/\/github\.com\/[^/]+\/[^/]+\/blob\//i.test(url);
        const target = isBlob
            ? url.split("#")[0] + (url.includes("?") ? "&" : "?") + "plain=1"
            : url;
        const res = await fetch(target, { credentials: "include" });
        if (!res.ok) return { ok: false, error: "HTTP " + res.status };
        const text = await res.text();
        if (/^\s*(?:<!doctype\s+html|<html[\s>])/i.test(text.slice(0, 200))) {
            const raw = pullRawLines(text);
            if (raw != null) return { ok: true, text: raw };
        }
        return { ok: true, text };
    } catch (e) {
        return { ok: false, error: String((e && e.message) || e) };
    }
}
