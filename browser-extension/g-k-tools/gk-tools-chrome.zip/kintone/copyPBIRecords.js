// Injected into the active kintone tab. It ONLY scrapes the record list and
// returns the text — clipboard writing is done back in the popup (which is the
// focused, user-activated surface), because document.execCommand/clipboard from
// an injected script fails when the extension popup owns the focus.
// Classic script (usable BOTH as a <script src> in the popup and via
// scripting.executeScript({files}) from the background) — registers itself
// on globalThis.GKScrape. No ES import/export on purpose.
(function () {
    "use strict";
    function scrapePBIRecords(columnsCsv) {
        const inputs = (columnsCsv || "Key,Summary")
            .split(",")
            .map(s => s.trim())
            .filter(Boolean);

        const $table = document.querySelector("table.recordlist-consistent-column-width-gaia");
        if (!$table) {
            // Record detail view (/k/<app>/show#record=<id>): single record, fields
            // rendered as .control-gaia blocks. Output "<value>: <value>" for the
            // requested columns (e.g. "GTM-21532: <summary>").
            const fieldValue = (label) => {
                for (const f of document.querySelectorAll(".control-gaia")) {
                    const lbl = f.querySelector(".control-label-text-gaia");
                    if (lbl && lbl.textContent.trim() === label) {
                        const v = f.querySelector(".control-value-gaia");
                        return v ? v.innerText.trim() : "";
                    }
                }
                return null;
            };
            const values = inputs.map(fieldValue).filter((v) => v);
            if (!values.length) {
                return { ok: false, error: "No record list or matching fields (" + inputs.join(", ") + ") found." };
            }
            return { ok: true, text: values.join(": "), rows: 1 };
        }

        // map requested column names -> header indexes (keep header order)
        const headers = $table.querySelectorAll("th.recordlist-header-cell-gaia");
        const cols = [];
        let spIdx = -1;
        for (let i = 0; i < headers.length; i++) {
            const name = headers[i].innerText.trim();
            if (inputs.includes(name)) cols.push(i);
            if (name === "Story points") spIdx = i;
        }

        if (cols.length === 0) {
            return { ok: false, error: "Columns not found: " + inputs.join(", ") };
        }

        const rows = $table.querySelectorAll("tr.recordlist-row-gaia");
        let output = "";
        let totalStoryPoints = 0;

        rows.forEach(tr => {
            const tds = tr.getElementsByTagName("td");
            const items = cols.map(colIndex => (tds[colIndex]?.innerText || '').trim());
            output += "- " + items.join(": ") + "\n";

            if (spIdx >= 0 && tds[spIdx]) {
                totalStoryPoints += parseInt(tds[spIdx].innerText, 10) || 0;
            }
        });

        output += "Story Points: " + totalStoryPoints;
        return { ok: true, text: output, rows: rows.length };
    }

    (globalThis.GKScrape = globalThis.GKScrape || {}).scrapePBIRecords = scrapePBIRecords;
})();
