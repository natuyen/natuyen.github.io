"use strict";

/* Markdown parser: shared/markdown.js (loaded first by md-viewer.html) */
const { escapeHtml, parseMarkdown, slugify } = globalThis.GKMD;

/* Loading spinner: shared/spinner.js (loaded first by md-viewer.html) */
const showLoading = () => globalThis.GKSpin.show("Markdown Text Viewer — loading data…");
const hideLoading = () => globalThis.GKSpin.hide();

/* ---------- UI wiring ---------- */
const output = document.getElementById("output");
const statusEl = document.getElementById("status");
const fileNameEl = document.getElementById("fileName");
const fileInput = document.getElementById("fileInput");
const urlInput = document.getElementById("urlInput");
const loadUrlBtn = document.getElementById("loadUrlBtn");
const dropzone = document.getElementById("dropzone");

// "https://host/repo/blob/main/docs/test.md?plain=1" → "test.md"; a plain file
// name passes through unchanged. Falls back to the full label when the last
// path segment is empty (e.g. a URL ending in "/").
function baseName(label) {
  if (!label) return "";
  let name = label.split(/[?#]/)[0].replace(/\/+$/, "").split("/").pop();
  try { name = decodeURIComponent(name); } catch (e) {}
  return name || label;
}

// What the badge shows, never truncated by CSS:
//  - GitHub sources → the repo-relative PATH, like the "Files changed" view.
//    Specs are all called "index.md", so the directory is the only thing that
//    identifies them; the origin and the "/owner/repo/blob/<ref>/" prefix say
//    nothing about the document and are dropped.
//  - anything else → the file name alone.
// `serverName` wins when present: a Kintone attachment URL
// (/k/api/record/download.do/...) carries the real name only in its
// Content-Disposition header, which shared/docfetch.js reads for us.
let serverName = null;

function displayName(label) {
  if (serverName) return serverName;
  const name = baseName(label);
  if (!/^https?:/i.test(label || "")) return name;
  try {
    const u = new URL(label);
    if (u.hostname !== "github.com") return name;
    const m = u.pathname.match(/^\/[^/]+\/[^/]+\/(?:blob|raw|blame|tree)\/[^/]+\/(.+)$/);
    if (!m) return name;
    try { return decodeURIComponent(m[1]); } catch (e) { return m[1]; }
  } catch (e) { return name; }
}

const openSrcEl = document.getElementById("openSrc");

function showFileName(sourceLabel) {
  const shown = displayName(sourceLabel);
  fileNameEl.textContent = shown ? "📄 " + shown : "";
  fileNameEl.title = sourceLabel || "";       // full URL on hover
  fileNameEl.classList.toggle("show", !!shown);
  // ↗ opens the original document (GitHub page, Kintone attachment, …). Only a
  // real URL can be opened — a locally picked file has none.
  const isUrl = /^https?:/i.test(sourceLabel || "");
  openSrcEl.hidden = !isUrl;
  if (isUrl) openSrcEl.href = sourceLabel;
  // The tab strip can only show a few characters — keep the short name there.
  const short = serverName || baseName(sourceLabel);
  document.title = short ? short + " — Markdown Text Viewer" : "Markdown Text Viewer";
}

/* ---------- File picker: docs found on the source page ---------- */
// The context menu / popup hands over every .md/.txt/.log link of the page it
// was launched from, plus that page's tabId. Selecting one asks the background
// to fetch it IN THAT TAB's origin (cookies, no CORS → private repos work).
const pickerWrap = document.getElementById("pickerWrap");
const pickerBtn = document.getElementById("pickerBtn");
const pickerPanel = document.getElementById("pickerPanel");
let docLinks = [];
let sourceTabId = null;

function setPickerOpen(on) { pickerPanel.hidden = !on; }
pickerBtn.addEventListener("click", (e) => { e.stopPropagation(); setPickerOpen(pickerPanel.hidden); });
document.addEventListener("click", (e) => {
  if (!pickerWrap.contains(e.target)) setPickerOpen(false);
});

function buildPicker(links, activeHref) {
  docLinks = links || [];
  // A single file is already open — no point offering a one-item list.
  if (docLinks.length < 2) { pickerWrap.hidden = true; return; }
  pickerWrap.hidden = false;
  pickerBtn.textContent = `📚 ${docLinks.length} files ▾`;
  pickerPanel.textContent = "";
  docLinks.forEach((l) => {
    const item = document.createElement("button");
    item.type = "button";
    item.className = "picker-item" + (l.href === activeHref ? " current" : "");
    item.title = l.href;
    item.textContent = l.name;
    if (l.file && l.file !== l.name) {
      const f = document.createElement("span");
      f.className = "pi-file";
      f.textContent = l.file;
      item.appendChild(f);
    }
    item.addEventListener("click", () => { setPickerOpen(false); loadFromPage(l.href); });
    pickerPanel.appendChild(item);
  });
}

// Fetch a picked file through the background (source-tab origin), then render.
async function loadFromPage(url) {
  statusEl.textContent = "Loading…";
  showLoading();
  try {
    const r = await ext.runtime.sendMessage({ type: "gkFetchDoc", url, tabId: sourceTabId });
    if (!r || !r.ok) throw new Error((r && r.error) || "could not read the file");
    serverName = r.name || null;
    render(r.text, url);
    buildPicker(docLinks, url);          // keep the list, move the "current" mark
  } catch (e) {
    statusEl.textContent = `Failed to load ${url} (${e.message}).`;
  } finally {
    hideLoading();
  }
}

/* ---------- Sticky-header offset for anchor jumps ---------- */
// Keeps --sticky-h in sync with the real header height so scroll-margin-top
// lands anchor targets just below it. The header wraps (long file names, narrow
// windows), so it is re-measured on resize and after every render.
const headerEl = document.querySelector("header");
function syncStickyOffset() {
  const h = Math.ceil(headerEl.getBoundingClientRect().height) + 10;
  document.documentElement.style.setProperty("--sticky-h", h + "px");
}
addEventListener("resize", syncStickyOffset);
if (typeof ResizeObserver === "function") new ResizeObserver(syncStickyOffset).observe(headerEl);
syncStickyOffset();

/* ---------- Table of contents ---------- */
const tocBtn = document.getElementById("tocBtn");
const tocPanel = document.getElementById("tocPanel");
const tocList = document.getElementById("tocList");

const mainEl = document.querySelector("main");
const tocSplit = document.getElementById("tocSplit");

// The TOC starts open on every run of the viewer. Only a click on the toggle
// flips this, and then only for the rest of that tab's session — a closed panel
// is never carried over to the next time the tool is opened.
let tocUserSet = false;
// Left over from when the closed state was persisted; drop it so a stale value
// cannot confuse anyone reading storage later.
try { localStorage.removeItem("gkMdTocOpen"); } catch (e) {}

function setTocVisible(on) {
  tocPanel.hidden = !on;
  tocSplit.hidden = !on;
  tocBtn.classList.toggle("active", on);
  tocBtn.title = on ? "Hide the table of contents" : "Show the table of contents";
  // `main` gives its left padding to the flush-left sidebar; take it back when
  // the sidebar is gone so the text does not touch the screen edge.
  mainEl.classList.toggle("no-toc", !on);
}

/* ---------- Resizable TOC pane ---------- */
// Drag the hairline between the panes to trade sidebar width for reading width
// (long spec paths need a wide TOC; prose reads better with a narrow one).
// Width is clamped so neither pane can be dragged away entirely, and remembered.
const TOC_W_MIN = 170, TOC_W_MAX = 620, TOC_W_DEFAULT = 264;

function setTocWidth(px, persist) {
  const w = Math.max(TOC_W_MIN, Math.min(TOC_W_MAX, Math.round(px)));
  document.documentElement.style.setProperty("--toc-w", w + "px");
  if (persist) { try { localStorage.setItem("gkMdTocW", String(w)); } catch (e) {} }
  return w;
}

try {
  const saved = parseInt(localStorage.getItem("gkMdTocW"), 10);
  if (saved) setTocWidth(saved, false);
} catch (e) {}

tocSplit.addEventListener("pointerdown", (e) => {
  e.preventDefault();
  // Pointer capture is a nicety (it keeps events flowing when the cursor leaves
  // the 7px handle) but must not be load-bearing: if it throws, the drag still
  // has to work, so the listeners live on window either way.
  try { tocSplit.setPointerCapture(e.pointerId); } catch (err) {}
  tocSplit.classList.add("dragging");
  document.body.classList.add("resizing");
  // main has no left padding, so the pointer's x IS the desired width.
  const widthAt = (ev) => ev.clientX - mainEl.getBoundingClientRect().left;
  const move = (ev) => setTocWidth(widthAt(ev), false);
  const up = (ev) => {
    setTocWidth(widthAt(ev), true);
    tocSplit.classList.remove("dragging");
    document.body.classList.remove("resizing");
    removeEventListener("pointermove", move);
    removeEventListener("pointerup", up);
    removeEventListener("pointercancel", up);
  };
  addEventListener("pointermove", move);
  addEventListener("pointerup", up);
  addEventListener("pointercancel", up);
});

tocSplit.addEventListener("dblclick", () => setTocWidth(TOC_W_DEFAULT, true));

tocBtn.addEventListener("click", () => { tocUserSet = true; setTocVisible(tocPanel.hidden); });

// Build the sidebar from the rendered headings, one indent level per heading
// rank. Opened automatically whenever the document has 3+ headings, unless the
// user has closed it by hand in this session.
// Ids come from the parser (slug, or an explicit "{#custom-id}") — keep those so
// a TOC written inside the document keeps resolving; only fill in a missing id
// or de-duplicate a repeated one (spec files reuse titles like "Error").
function buildToc() {
  tocList.textContent = "";
  const heads = output.querySelectorAll("h1, h2, h3, h4, h5, h6");
  const seen = Object.create(null);
  heads.forEach(h => {
    const base = h.id || slugify(h.textContent || "").slice(0, 80) || "section";
    const n = (seen[base] = (seen[base] || 0) + 1);
    if (!h.id || n > 1) h.id = n > 1 ? `${base}-${n}` : base;
    const a = document.createElement("a");
    a.href = "#" + h.id;
    a.textContent = h.textContent;
    a.title = h.textContent;
    a.className = "lv" + h.tagName[1];
    a.addEventListener("click", e => {
      e.preventDefault();
      h.scrollIntoView({ behavior: "smooth", block: "start" });
      history.replaceState(null, "", "#" + h.id);
    });
    tocList.appendChild(a);
  });
  const enough = heads.length >= 3;
  tocBtn.hidden = !enough;
  // Auto-open unless the user already made a choice in this session; a document
  // without enough headings has no sidebar to show either way.
  const open = enough && (!tocUserSet || !tocPanel.hidden);
  setTocVisible(open);
  watchHeadings(heads);
}

/* ---------- Scrollspy: highlight the section being read ---------- */
// Highlights the last heading whose top has passed under the sticky header, so
// the sidebar always points at the section on screen — long specs otherwise
// leave you guessing where you are. Plain scroll math (not IntersectionObserver)
// because a heading can be taller than the observer's root margin and because
// the sticky offset changes when the header wraps.
let spyHeads = [];
let spyRaf = 0;

function watchHeadings(heads) {
  spyHeads = [...heads];
  updateActiveHeading();
}

function updateActiveHeading() {
  if (!spyHeads.length || tocPanel.hidden) return;
  const offset = parseInt(getComputedStyle(document.documentElement).getPropertyValue("--sticky-h")) || 120;
  let activeId = spyHeads[0].id;
  for (const h of spyHeads) {
    if (h.getBoundingClientRect().top - offset <= 1) activeId = h.id;
    else break;
  }
  // At the very bottom the last section is on screen even if its heading is not.
  if (innerHeight + scrollY >= document.documentElement.scrollHeight - 2) {
    activeId = spyHeads[spyHeads.length - 1].id;
  }
  let current = null;
  tocList.querySelectorAll("a").forEach((a) => {
    const on = a.getAttribute("href") === "#" + activeId;
    a.classList.toggle("current", on);
    if (on) current = a;
  });
  // Keep the highlighted row in view without yanking the whole page.
  if (current) {
    const p = tocPanel.getBoundingClientRect(), r = current.getBoundingClientRect();
    if (r.top < p.top + 4) tocPanel.scrollTop -= p.top + 4 - r.top;
    else if (r.bottom > p.bottom - 4) tocPanel.scrollTop += r.bottom - (p.bottom - 4);
  }
}

addEventListener("scroll", () => {
  if (spyRaf) return;
  spyRaf = requestAnimationFrame(() => { spyRaf = 0; updateActiveHeading(); });
}, { passive: true });

/* ---------- Relative images / links ---------- */
// Spec files reference images relatively ("![](9edc8ab0-….avif)"). Rendered in
// this extension page, such a src resolves against moz-extension://…/tools/ and
// 404s, so it must be re-based on the document's own URL. For GitHub the base is
// the "/raw/" path, not "/blob/" (blob serves an HTML page); /raw/ redirects to a
// signed URL and the browser follows it with the session cookies, so images in
// PRIVATE repos load too.
function assetBase(label) {
  if (!/^https?:/i.test(label || "")) return null;
  try {
    const u = new URL(label);
    const m = u.pathname.match(/^\/([^/]+)\/([^/]+)\/blob\/([^/]+)\/(.*)$/);
    if (u.hostname === "github.com" && m) {
      const dir = m[4].replace(/[^/]*$/, "");            // drop the file name
      return {
        img: `${u.origin}/${m[1]}/${m[2]}/raw/${m[3]}/${dir}`,
        link: `${u.origin}/${m[1]}/${m[2]}/blob/${m[3]}/${dir}`,
      };
    }
    const base = u.href.split(/[?#]/)[0].replace(/[^/]*$/, "");
    return { img: base, link: base };
  } catch (e) { return null; }
}

const ABSOLUTE = /^(?:[a-z][a-z0-9+.-]*:|\/\/)/i;

function resolveAssets(label) {
  const b = assetBase(label);
  output.querySelectorAll("img[src]").forEach((img) => {
    const raw = img.getAttribute("src");
    if (!raw) return;
    if (!ABSOLUTE.test(raw) && b) { try { img.src = new URL(raw, b.img).href; } catch (e) {} }
    // Say so instead of leaving a silent blank: a broken image in a spec is
    // usually a missing asset, and guessing wastes the reader's time.
    img.addEventListener("error", () => {
      if (img.dataset.gkFailed) return;
      img.dataset.gkFailed = "1";
      const note = document.createElement("span");
      note.className = "img-missing";
      note.textContent = "🖼 image not available: " + raw;
      note.title = img.src;
      img.replaceWith(note);
    });
  });
  output.querySelectorAll("a[href]").forEach((a) => {
    const raw = a.getAttribute("href");
    if (!raw || raw.charAt(0) === "#" || ABSOLUTE.test(raw) || !b) return;
    try { a.href = new URL(raw, b.link).href; a.target = "_blank"; a.rel = "noopener noreferrer"; } catch (e) {}
  });
}

/* ---------- Code blocks: copy button ---------- */
// Older but gesture-free path, used when the async clipboard API refuses (no
// permission, or a click that the browser does not treat as user activation).
function copyViaTextarea(text) {
  const ta = document.createElement("textarea");
  ta.value = text;
  ta.setAttribute("style", "position:fixed;top:-9999px;left:-9999px");
  document.body.appendChild(ta);
  ta.focus();
  ta.select();
  let ok = false;
  try { ok = document.execCommand("copy"); } catch (e) { ok = false; }
  ta.remove();
  return ok;
}

// Garoon specs keep their CoA in fenced blocks and those get pasted into tickets
// all day, so every block gets a hover-revealed copy button.
function addCodeCopyButtons() {
  output.querySelectorAll("pre").forEach((pre) => {
    if (pre.classList.contains("plain") || pre.parentElement.classList.contains("code-wrap")) return;
    const wrap = document.createElement("div");
    wrap.className = "code-wrap";
    pre.replaceWith(wrap);
    wrap.appendChild(pre);

    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "code-copy";
    btn.textContent = "Copy";
    btn.addEventListener("click", async () => {
      const code = (pre.querySelector("code") || pre).textContent;
      let ok = false;
      try { await navigator.clipboard.writeText(code); ok = true; } catch (e) { ok = false; }
      if (!ok) ok = copyViaTextarea(code);   // no clipboard permission / no gesture
      btn.textContent = ok ? "Copied ✓" : "Copy failed";
      btn.classList.toggle("done", ok);
      setTimeout(() => { btn.textContent = "Copy"; btn.classList.remove("done"); }, 1600);
    });
    wrap.appendChild(btn);
  });
}

/* ---------- Images: click to zoom ---------- */
// Spec screenshots are squeezed into the text column and their captions become
// unreadable; a full-screen overlay is the cheapest way to actually read them.
const lightbox = document.getElementById("lightbox");
const lightboxImg = document.getElementById("lightboxImg");

function openLightbox(src, alt) {
  lightboxImg.src = src;
  lightboxImg.alt = alt || "";
  lightbox.hidden = false;
}
function closeLightbox() {
  lightbox.hidden = true;
  lightboxImg.removeAttribute("src");
}
lightbox.addEventListener("click", closeLightbox);

function enableImageZoom() {
  output.querySelectorAll("img").forEach((img) => {
    img.addEventListener("click", () => {
      if (img.naturalWidth) openLightbox(img.currentSrc || img.src, img.alt);
    });
  });
}

/* ---------- Back to top ---------- */
const toTopBtn = document.getElementById("toTop");
toTopBtn.addEventListener("click", () => scrollTo({ top: 0, behavior: "smooth" }));
addEventListener("scroll", () => { toTopBtn.hidden = scrollY < 600; }, { passive: true });

addEventListener("keydown", (e) => {
  if (e.key === "Escape" && !lightbox.hidden) { closeLightbox(); return; }
  // Home/End are the natural jumps in a 25 000px spec; skip while typing.
  const typing = /^(INPUT|TEXTAREA)$/.test((e.target && e.target.tagName) || "");
  if (typing || e.metaKey || e.ctrlKey || e.altKey) return;
  if (e.key === "Home") { e.preventDefault(); scrollTo({ top: 0, behavior: "smooth" }); }
  else if (e.key === "End") { e.preventDefault(); scrollTo({ top: document.documentElement.scrollHeight, behavior: "smooth" }); }
});

/* ---------- Render mode: Markdown vs plain text ---------- */
// A .txt file is plain text, so running it through the Markdown parser would
// mangle it (line breaks collapsed into paragraphs, "*" turned into <em>…).
// Default by extension, and let the user override — some .txt files (e.g. the
// retro reports) are markdown-ish and read better rendered.
const modeBtn = document.getElementById("modeBtn");
let currentText = null;      // last loaded content, for re-render on toggle
let currentLabel = "";
let modeOverride = null;     // null = auto (by extension), else "md" | "txt"

const isTxtFile = (label) => /\.(txt|text|log)$/i.test(serverName || baseName(label));
const effectiveMode = (label) => modeOverride || (isTxtFile(label) ? "txt" : "md");

function updateModeBtn(mode) {
  modeBtn.hidden = currentText === null;
  modeBtn.textContent = mode === "txt" ? "📄 Plain text" : "📝 Markdown";
  modeBtn.title = mode === "txt"
    ? "Showing plain text — click to render as Markdown"
    : "Rendering Markdown — click to show plain text";
}

modeBtn.addEventListener("click", () => {
  if (currentText === null) return;
  modeOverride = effectiveMode(currentLabel) === "txt" ? "md" : "txt";
  render(currentText, currentLabel, true);
});

function render(text, sourceLabel, keepOverride) {
  try {
    if (!keepOverride) modeOverride = null;   // a new file resets to auto
    currentText = text;
    currentLabel = sourceLabel || "";
    const mode = effectiveMode(sourceLabel);

    if (mode === "txt") {
      const pre = document.createElement("pre");
      pre.className = "plain numbered";
      // One <span> per line: the CSS counter draws the line number in ::before,
      // which keeps it out of the text selection. textContent everywhere → no
      // HTML injection.
      for (const line of String(text).replace(/\r\n?/g, "\n").split("\n")) {
        const row = document.createElement("span");
        row.className = "pl";
        row.textContent = line || "\u200b";   // keep empty lines numbered
        pre.appendChild(row);
      }
      output.textContent = "";
      output.appendChild(text ? pre : Object.assign(document.createElement("p"),
        { className: "empty", textContent: "(Empty file)" }));
    } else {
      output.innerHTML = parseMarkdown(text) || '<p class="empty">(Empty file)</p>';
      resolveAssets(sourceLabel);
      addCodeCopyButtons();
      enableImageZoom();
    }

    statusEl.textContent = "";     // the file name badge already says what is open
    showFileName(sourceLabel);
    updateModeBtn(mode);
    buildToc();                               // no headings in plain mode → hides itself
    syncStickyOffset();                       // header height changes with the file name
    if (searchInput.value.trim()) runSearch();
  } catch (e) {
    output.innerHTML = `<p style="color:#cf222e">Render error: ${escapeHtml(e.message)}</p>`;
  }
}

function readFile(file) {
  serverName = null;
  showLoading();
  const reader = new FileReader();
  reader.onload = e => { hideLoading(); render(e.target.result, file.name); };
  reader.onerror = () => { hideLoading(); statusEl.textContent = "Could not read file."; };
  reader.readAsText(file, "utf-8");
}

fileInput.addEventListener("change", e => { if (e.target.files[0]) readFile(e.target.files[0]); });

async function loadUrl() {
  const url = urlInput.value.trim();
  if (!url) return;
  statusEl.textContent = "Loading…";
  serverName = null;
  showLoading();
  try {
    const res = await fetch(url);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    render(await res.text(), url);
  } catch (e) {
    statusEl.textContent = `Failed to load URL (${e.message}). Likely a CORS issue — try the file's "raw" link.`;
  } finally {
    hideLoading();
  }
}
loadUrlBtn.addEventListener("click", loadUrl);
urlInput.addEventListener("keydown", e => { if (e.key === "Enter") loadUrl(); });

// drag & drop — listen on the whole window so drops on empty area also work
let dragDepth = 0;
window.addEventListener("dragenter", e => { e.preventDefault(); dragDepth++; dropzone.classList.add("dragover"); });
window.addEventListener("dragover", e => { e.preventDefault(); });
window.addEventListener("dragleave", e => { e.preventDefault(); if (--dragDepth <= 0) { dragDepth = 0; dropzone.classList.remove("dragover"); } });
window.addEventListener("drop", e => {
  e.preventDefault();
  dragDepth = 0;
  dropzone.classList.remove("dragover");
  const file = e.dataTransfer.files[0];
  if (file) readFile(file);
});

// ---------- Search / highlight ----------
const searchInput = document.getElementById("searchInput");
const searchCount = document.getElementById("searchCount");
const searchPrev = document.getElementById("searchPrev");
const searchNext = document.getElementById("searchNext");
let hits = [], hitIndex = -1;

function clearHighlights() {
  output.querySelectorAll("mark.md-hit").forEach(m => {
    const parent = m.parentNode;
    parent.replaceChild(document.createTextNode(m.textContent), m);
    parent.normalize();
  });
  hits = []; hitIndex = -1;
}

function runSearch() {
  clearHighlights();
  const term = searchInput.value.trim();
  if (!term) { searchCount.textContent = "0/0"; return; }
  const lower = term.toLowerCase();
  const walker = document.createTreeWalker(output, NodeFilter.SHOW_TEXT, {
    acceptNode: node => node.nodeValue.toLowerCase().includes(lower) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT
  });
  const textNodes = [];
  let n; while ((n = walker.nextNode())) textNodes.push(n);
  textNodes.forEach(node => {
    const text = node.nodeValue, low = text.toLowerCase();
    const frag = document.createDocumentFragment();
    let idx = 0, pos;
    while ((pos = low.indexOf(lower, idx)) !== -1) {
      if (pos > idx) frag.appendChild(document.createTextNode(text.slice(idx, pos)));
      const mark = document.createElement("mark");
      mark.className = "md-hit";
      mark.textContent = text.slice(pos, pos + term.length);
      frag.appendChild(mark);
      idx = pos + term.length;
    }
    if (idx < text.length) frag.appendChild(document.createTextNode(text.slice(idx)));
    node.parentNode.replaceChild(frag, node);
  });
  hits = Array.from(output.querySelectorAll("mark.md-hit"));
  hitIndex = hits.length ? 0 : -1;
  focusHit();
}

function focusHit() {
  hits.forEach(h => h.classList.remove("current"));
  const cur = hits[hitIndex];
  if (cur) { cur.classList.add("current"); cur.scrollIntoView({ block: "center", behavior: "smooth" }); }
  searchCount.textContent = hits.length ? `${hitIndex + 1}/${hits.length}` : "0/0";
}

function nextHit(dir) {
  if (!hits.length) return;
  hitIndex = (hitIndex + dir + hits.length) % hits.length;
  focusHit();
}

let searchTimer;
searchInput.addEventListener("input", () => { clearTimeout(searchTimer); searchTimer = setTimeout(runSearch, 200); });
searchInput.addEventListener("keydown", e => {
  if (e.key === "Enter") { e.preventDefault(); hits.length ? nextHit(e.shiftKey ? -1 : 1) : runSearch(); }
  else if (e.key === "Escape") { searchInput.value = ""; clearHighlights(); searchCount.textContent = "0/0"; }
});
searchNext.addEventListener("click", () => nextHit(1));
searchPrev.addEventListener("click", () => nextHit(-1));

// Ctrl/Cmd+F focuses the in-page search
window.addEventListener("keydown", e => {
  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "f") { e.preventDefault(); searchInput.focus(); searchInput.select(); }
});

// Auto-load:
//  ?src=local  → content was fetched by the extension and handed off via storage
//  ?md= / ?url= → fetch the URL directly (works for public / CORS-open hosts)
const params = new URLSearchParams(location.search);
const ext = (typeof browser !== "undefined") ? browser : (typeof chrome !== "undefined" ? chrome : null);

if (params.get("src") === "local" && ext && ext.storage) {
  statusEl.textContent = "Loading…";
  showLoading();
  Promise.resolve(ext.storage.local.get("gkMdPayload")).then(data => {
    const p = data && data.gkMdPayload;
    if (!p) { statusEl.textContent = "No content was handed off."; return; }
    ext.storage.local.remove("gkMdPayload");
    sourceTabId = p.tabId != null ? p.tabId : null;
    serverName = p.name || null;
    buildPicker(p.links, p.source);
    if (typeof p.text === "string") {
      urlInput.value = p.source || "";
      render(p.text, p.source || "(loaded)");
    } else if (p.links && p.links.length) {
      // Opened from the popup: nothing pre-fetched, so show the list right away.
      statusEl.textContent = `Found ${p.links.length} file(s) on the page — pick one to view.`;
      if (p.links.length > 1) setPickerOpen(true);
      else loadFromPage(p.links[0].href);
    } else {
      statusEl.textContent = "No content was handed off.";
    }
  }).catch(e => { statusEl.textContent = "Storage error: " + e.message; })
    .finally(hideLoading);
} else {
  const qUrl = params.get("md") || params.get("url");
  if (qUrl) { urlInput.value = qUrl; loadUrl(); }
}
