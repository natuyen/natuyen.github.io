/* Git Markdown Viewer — renders both versions of every changed .md file in a
 * GitHub Pull Request side-by-side (GitHub-style split view) and highlights the
 * differences on the RENDERED content. Self-contained, no external libraries.
 * Injected by background.js (context menu "GK Tools - Git Markdown Viewer") as a
 * content script, so it is exempt from the page CSP and uses the logged-in
 * cookies (private repos work).
 * Source of truth: work_tools/garoon/tools/git-md-viewer/git-md-viewer.js —
 * edit there first, then copy here. */
(function () {
  'use strict';
  const VERSION = 'v12';
  try { console.log('[git-md-viewer] ' + VERSION + ' loaded'); } catch (e) {}
  const $ = (t, s, kids) => {
    const n = document.createElement(t);
    if (s) n.setAttribute('style', s);
    (kids || []).forEach(k => n.appendChild(typeof k === 'string' ? document.createTextNode(k) : k));
    return n;
  };
  const stripIds = s => s.replace(/\s+local-id="[^"]*"/g, '');
  const keyOf = el => (el.textContent || '').replace(/\s+/g, ' ').trim();

  /* Markdown parser comes from shared/markdown.js — injected BEFORE this file
   * (background.js / popup.js pass files: ['shared/markdown.js', 'tools/git-md-viewer.js']). */
  const { parseMarkdown } = globalThis.GKMD;

  function renderMd(md) {
    const box = document.createElement('div');
    box.className = 'grd-md';
    box.innerHTML = parseMarkdown(stripIds(md));
    return box;
  }

  // Spec files start with a hand-written markdown TOC of "#anchor" links. Both
  // panes render the same document, so heading ids would collide — namespace
  // them per pane and rewrite that pane's own links to match, then scroll
  // inside the overlay instead of letting the browser navigate the PR page.
  let paneSeq = 0;
  function wireAnchors(box) {
    const prefix = 'grd' + (++paneSeq) + '-';
    box.querySelectorAll('[id]').forEach(el => { el.id = prefix + el.id; });
    box.querySelectorAll('a[href^="#"]').forEach(a => {
      const target = a.getAttribute('href').slice(1);
      if (!target) return;
      a.setAttribute('href', '#' + prefix + target);
    });
    box.addEventListener('click', e => {
      const a = e.target.closest && e.target.closest('a[href^="#"]');
      if (!a || !box.contains(a)) return;
      e.preventDefault();
      const id = a.getAttribute('href').slice(1);
      // getElementById would find the OTHER pane's copy on a prefix mishap;
      // scope the lookup to this pane.
      const dest = box.querySelector('[id="' + CSS.escape(id) + '"]');
      if (!dest) return;
      dest.scrollIntoView({ block: 'center', behavior: 'smooth' });
      dest.classList.add('grd-flash');
      setTimeout(() => dest.classList.remove('grd-flash'), 1200);
    });
  }

  // innermost text blocks — table cells, list items, paragraphs, headings
  const SEL = 'td,th,li,p,h1,h2,h3,h4,h5,h6,pre,blockquote';
  function units(root) {
    return [...root.querySelectorAll(SEL)].filter(el => !el.querySelector(SEL));
  }

  // LCS by key → which units on each side are unmatched (changed).
  //
  // The walk also groups the changes: everything unmatched between one pair of
  // matching units is one "hunk", holding the old-side indices it removed and
  // the new-side indices it added. That pairing is what lets a badge read 2-o on
  // the left and 2-n on the right for the SAME change, instead of two unrelated
  // numbers. `groups` is null when the size guard skips the diff.
  //
  // `pairs` holds the opposite: every [i, j] of units that DID match. Those are
  // the rows the two panes have in common, and lining them up is what keeps the
  // split view symmetric (see alignPanes).
  function diffFlags(a, b) {
    const n = a.length, m = b.length;
    const aCh = new Array(n).fill(true), bCh = new Array(m).fill(true);
    if (n * m > 4e6) return { aCh, bCh, groups: null, pairs: [] }; // guard
    const dp = [];
    for (let i = 0; i <= n; i++) dp.push(new Int32Array(m + 1));
    for (let i = n - 1; i >= 0; i--)
      for (let j = m - 1; j >= 0; j--)
        dp[i][j] = a[i] === b[j] ? dp[i + 1][j + 1] + 1 : Math.max(dp[i + 1][j], dp[i][j + 1]);
    let i = 0, j = 0;
    const groups = [], pairs = [];
    let cur = null;
    while (i < n || j < m) {
      if (i < n && j < m && a[i] === b[j]) {
        aCh[i] = false; bCh[j] = false; pairs.push([i, j]);
        i++; j++; cur = null;   // match ends the hunk
      } else {
        if (!cur) { cur = { a: [], b: [] }; groups.push(cur); }
        // Past the end of one side, or the table says advancing there loses less.
        if (j >= m || (i < n && dp[i + 1][j] >= dp[i][j + 1])) { cur.a.push(i); i++; }
        else { cur.b.push(j); j++; }
      }
    }
    return { aCh, bCh, groups, pairs };
  }

  // Stamps each changed unit with its hunk number, so the badges can be paired.
  function highlight(unitList, flags, kind, groupOf) {
    let count = 0;
    unitList.forEach((el, i) => {
      if (flags[i]) {
        el.classList.add(kind);
        const g = groupOf && groupOf.get(i);
        if (g) el.dataset.grdGroup = g;
        count++;
      }
    });
    return count;
  }

  // unit index -> hunk number (1-based), per side
  function groupIndex(groups, side) {
    const map = new Map();
    (groups || []).forEach((g, gi) => g[side].forEach(idx => map.set(idx, gi + 1)));
    return map;
  }

  /* ---- symmetric panes, the way GitHub's split view does it ----------------
   * A change that exists on one side only (a pure add or delete) leaves the other
   * side with nothing to show, so the two panes drift apart and a change ends up
   * beside unrelated text. Fix it the same way GitHub does: pad the short side
   * with blank filler so every change starts — and ends — at the same height on
   * both sides. Runs after every layout change (mode toggle, collapse, resize),
   * so it works in "Changes only" and in full mode alike.
   */
  const visible = el => !!(el && el.offsetParent);

  // Filler has to be a legal child of wherever it is inserted: a row inside a
  // table, an item inside a list, a div anywhere else.
  function makeFiller(refEl, px) {
    const parent = refEl && refEl.parentElement;
    const tag = parent && /^(TBODY|THEAD|TFOOT|TABLE)$/.test(parent.tagName) ? 'TR'
              : parent && /^(UL|OL)$/.test(parent.tagName) ? 'LI'
              : 'DIV';
    if (tag === 'TR') {
      const tr = document.createElement('tr');
      tr.className = 'grd-filler';
      const td = document.createElement('td');
      td.colSpan = 99;
      td.style.cssText = `height:${px}px;padding:0;border-left:0;border-right:0`;
      tr.appendChild(td);
      return tr;
    }
    const el = document.createElement(tag === 'LI' ? 'li' : 'div');
    el.className = 'grd-filler';
    el.style.cssText = `height:${px}px` + (tag === 'LI' ? ';list-style:none' : '');
    return el;
  }

  // Insert `px` of blank space just above refEl (or at the end of `pane` when the
  // hunk has nothing after it on this side). Returns the box whose height can be
  // trimmed afterwards — a table filler carries its height on the inner cell.
  function pad(pane, refEl, px) {
    if (px < 1) return null;
    // A cell belongs to its row — push the whole row down, not the text in it.
    let ref = refEl;
    if (ref && /^(TD|TH)$/.test(ref.tagName)) ref = ref.closest('tr');
    let f;
    if (ref && ref.parentElement) {
      f = makeFiller(ref, px);
      ref.parentElement.insertBefore(f, ref);
    } else {
      const md = [...pane.querySelectorAll('.grd-md')].pop();
      if (!md) return null;
      f = makeFiller(md.firstElementChild, px);
      md.appendChild(f);
    }
    return f.tagName === 'TR' ? f.firstElementChild : f;
  }

  // Block margins collapse (or stack) around an inserted filler, so a filler of
  // exactly N px rarely moves the content by exactly N px. Measure the residual
  // and trim; two or three passes land it on the pixel.
  function converge(box, residual) {
    for (let k = 0; k < 4; k++) {
      const err = residual();
      if (Math.abs(err) < 1) break;
      const h = Math.max(0, parseFloat(box.style.height || 0) + err);
      box.style.height = h + 'px';
      if (h === 0) break;
    }
  }

  /* ---- rows: numbers, rules across both panes, and row selection -----------
   * The rendered document has blocks, not source lines, so a "row" here is a set
   * of units that share a vertical position — one table row, one paragraph, or a
   * changed block beside its counterpart. Once the panes are aligned, bucketing
   * the units by their measured top gives exactly the rows GitHub draws.
   */
  function rowsOf(unitList, base) {
    const top0 = base.getBoundingClientRect().top;
    const rows = [];
    unitList.filter(visible).forEach(el => {
      const r = el.getBoundingClientRect();
      const top = r.top - top0, bottom = r.bottom - top0;
      const last = rows[rows.length - 1];
      // same visual line → same row (table cells sit side by side)
      if (last && Math.abs(top - last.top) < 4) {
        last.bottom = Math.max(last.bottom, bottom);
        last.els.push(el);
      } else {
        rows.push({ top, bottom, els: [el] });
      }
    });
    return rows;
  }

  // Numbers live in each pane's own gutter, so each side counts its own rows —
  // the same way a split diff numbers old and new independently.
  function paintGutter(pane, rows) {
    pane.querySelectorAll('.grd-lineno').forEach(n => n.remove());
    rows.forEach((row, i) => {
      const n = document.createElement('span');
      n.className = 'grd-lineno';
      n.textContent = String(i + 1);
      n.style.top = row.top + 'px';
      n.dataset.row = i;
      n.title = 'Line ' + (i + 1) + ' — click to select it on this side';
      pane.appendChild(n);
      row.no = n;
    });
  }

  // A layer above both panes, holding the highlight band for the selected row.
  // (It used to draw a rule at every row boundary as well; with a row per
  // paragraph and table cell that was more noise than guide, so the rules are
  // gone and the band alone marks a line.)
  function ensureBand(cols) {
    let layer = cols.querySelector('.grd-layer');
    if (!layer) {
      layer = document.createElement('div');
      layer.className = 'grd-layer';
      cols.insertBefore(layer, cols.firstChild);
    }
    layer.textContent = '';
    const band = document.createElement('div');
    band.className = 'grd-band';
    band.style.display = 'none';
    layer.appendChild(band);
    return band;
  }

  // Rows merged across the panes — what "the whole line, both sides" means.
  function mergeRows(rowsO, rowsN) {
    const all = [...rowsO, ...rowsN].sort((a, b) => a.top - b.top);
    const out = [];
    for (const r of all) {
      const last = out[out.length - 1];
      if (last && r.top - last.top < 4) { last.bottom = Math.max(last.bottom, r.bottom); }
      else out.push({ top: r.top, bottom: r.bottom });
    }
    return out;
  }

  // "Changes only" trims each side independently, so a line kept as context on
  // one side can be hidden on the other — and a hidden row cannot be aligned.
  // Reveal the missing half of every shared pair so both panes show the same
  // context, the way GitHub's split view does.
  function syncVisibility(ua, ub, pairs) {
    const show = (el, pane) => {
      for (let n = el; n && n !== pane; n = n.parentElement) {
        if (n.style && n.style.display === 'none') n.style.display = '';
      }
    };
    for (const [i, j] of pairs || []) {
      const A = ua[i], B = ub[j];
      if (!A || !B) continue;
      if (visible(A) && !visible(B)) show(B, null);
      else if (!visible(A) && visible(B)) show(A, null);
    }
  }

  // Align on the units the two sides SHARE, walking top to bottom. Padding the
  // higher of a matching pair down means everything between two matches — a
  // changed block, a pure insertion, a pure deletion — is bracketed by two
  // aligned rows, so each change starts level with its counterpart and a
  // one-sided change leaves blank space opposite it. No special case needed for
  // add-only or delete-only hunks: the next shared row does the work.
  function alignPanes(paneOld, paneNew, ua, ub, pairs, groups) {
    [paneOld, paneNew].forEach(p => p.querySelectorAll('.grd-filler').forEach(f => f.remove()));
    if (!pairs || !pairs.length) return 0;

    const topOf = el => el.getBoundingClientRect().top;
    let added = 0;

    // Bring one pair of rows level by padding whichever sits higher.
    const level = (A, B) => {
      if (!visible(A) || !visible(B)) return 0;
      const gap = () => topOf(A) - topOf(B);
      const d = gap();
      if (Math.abs(d) < 2) return 0;            // already level, nothing to do
      // d > 0: the new side sits higher, so that is the side to push down. The
      // residual fed to converge flips sign with the side being padded.
      const box = d > 0 ? pad(paneNew, B, d) : pad(paneOld, A, -d);
      if (!box) return 0;
      converge(box, () => (d > 0 ? gap() : -gap()));
      added++;
      return 1;
    };

    const sweepPairs = () => pairs.reduce((n, [i, j]) => n + level(ua[i], ub[j]), 0);
    // The rows in common carry the layout; padding one shifts everything below it,
    // so a long document can hold a residual after the first sweep.
    sweepPairs();
    // A change's own two sides start right after an aligned row, but different
    // block margins (a paragraph against a list item, say) can still leave a few
    // pixels — level the two halves of each change directly.
    (groups || []).forEach(g => {
      const A = g.a.map(i => ua[i]).filter(visible), B = g.b.map(j => ub[j]).filter(visible);
      if (A.length && B.length) level(A[0], B[0]);
    });
    // Second sweep catches whatever the previous two shifted; it skips every pair
    // that is already level, so it costs almost nothing.
    sweepPairs();
    return added;
  }

  // "Only changes" mode: keep changed table rows / top-level blocks plus CTX
  // neighbours on each side for context, always keep header rows and headings.
  // `cls` = 'del' (old) or 'add' (new).
  const CTX = 2; // how many adjacent rows/blocks to keep around each change
  function collapse(colRoot, cls, on) {
    const isChanged = el => el.classList.contains(cls) || !!el.querySelector('.' + cls);
    // keep index i if it is changed, or within CTX of any changed index
    const nearChange = (i, changedIdx) => changedIdx.some(ci => Math.abs(ci - i) <= CTX);

    colRoot.querySelectorAll('table').forEach(tbl => {
      const anyChanged = !!tbl.querySelector('.' + cls);
      tbl.style.display = (on && !anyChanged) ? 'none' : '';
      const rows = [...tbl.querySelectorAll('tr')];
      if (!(on && anyChanged)) { rows.forEach(tr => tr.style.display = ''); return; }
      const changedIdx = rows.map((tr, i) => isChanged(tr) ? i : -1).filter(i => i >= 0);
      rows.forEach((tr, i) => {
        const isHeader = !!tr.querySelector('th');
        tr.style.display = (isHeader || nearChange(i, changedIdx)) ? '' : 'none';
      });
    });

    colRoot.querySelectorAll('.grd-md').forEach(md => {
      const blocks = [...md.children].filter(b => b.tagName !== 'TABLE');
      const changedIdx = blocks.map((b, i) => (!/^H[1-6]$/.test(b.tagName) && isChanged(b)) ? i : -1).filter(i => i >= 0);
      blocks.forEach((block, i) => {
        if (/^H[1-6]$/.test(block.tagName)) { block.style.display = ''; return; } // always keep headings
        block.style.display = (on && !nearChange(i, changedIdx)) ? 'none' : '';
      });
    });
  }

  function css(dark) {
    const c = dark
      ? { bg: '#0d1117', fg: '#e6edf3', bar: '#161b22', bd: '#30363d', mut: '#8b949e',
          delBg: 'rgba(248,81,73,.18)', delBd: '#f85149', addBg: 'rgba(63,185,80,.18)', addBd: '#3fb950', th: '#161b22',
          acc: '#1f6feb', accFg: '#fff' }
      : { bg: '#fff', fg: '#1f2328', bar: '#f6f8fa', bd: '#d0d7de', mut: '#59636e',
          delBg: '#ffebe9', delBd: '#cf222e', addBg: '#e6ffec', addBd: '#1a7f37', th: '#f6f8fa',
          acc: '#0969da', accFg: '#fff' };
    return `
#grd-ov{position:fixed;inset:0;z-index:2147483647;background:${c.bg};color:${c.fg};display:flex;flex-direction:column;font:14px system-ui,-apple-system,sans-serif}
#grd-ov .grd-bar{display:flex;align-items:center;gap:12px;background:${c.bar};border-bottom:1px solid ${c.bd};padding:10px 14px;flex:0 0 auto}
#grd-ov .grd-body{flex:1;overflow-y:auto;overflow-x:hidden}
#grd-ov .grd-panehead{position:sticky;top:0;z-index:4;display:flex;background:${c.bg};border-bottom:1px solid ${c.bd}}
#grd-ov .grd-panehead>div{flex:1;padding:6px 20px;font:600 12px system-ui;color:${c.mut};min-width:0}
#grd-ov .grd-panehead>div+div{border-left:1px solid ${c.bd}}
#grd-ov .grd-file{position:sticky;z-index:3;display:flex;align-items:center;gap:10px;background:${c.bar};border-top:1px solid ${c.bd};border-bottom:1px solid ${c.bd};padding:9px 16px;font:600 13px ui-monospace,monospace;color:${c.fg};word-break:break-all}
#grd-ov .grd-file .grd-file-counts{margin-left:auto;font-size:12px;font-weight:400;white-space:nowrap}
#grd-ov .grd-chevron{display:inline-flex;align-items:center;justify-content:center;background:transparent;border:1px solid transparent;color:${c.fg};cursor:pointer;font:16px system-ui;width:30px;height:30px;padding:0;border-radius:6px;flex:0 0 auto}
#grd-ov .grd-chevron:hover{background:${c.bg};border-color:${c.bd};color:${c.acc}}
#grd-ov .grd-cols{display:flex;position:relative}
#grd-ov .grd-pane{flex:1;padding:12px 20px 12px 52px;min-width:0;position:relative}
/* row furniture: a number per row in each pane's gutter, and a band that
   highlights the picked row (across both panes, or just one side) */
#grd-ov .grd-lineno{position:absolute;left:0;width:38px;text-align:right;
  font:11px/1.5 ui-monospace,monospace;color:${c.mut};user-select:none;cursor:pointer;z-index:2}
#grd-ov .grd-lineno:hover{color:${c.acc};text-decoration:underline}
#grd-ov .grd-lineno.on{color:${c.accFg};background:${c.acc};border-radius:3px}
#grd-ov .grd-layer{position:absolute;inset:0;pointer-events:none;z-index:0}
#grd-ov .grd-band{position:absolute;background:${c.acc}1f;box-shadow:inset 0 0 0 1px ${c.acc}66}
#grd-ov .grd-pane+.grd-pane{border-left:1px solid ${c.bd}}
#grd-ov .grd-dd{position:relative;display:inline-block}
#grd-ov .grd-dd-panel{position:absolute;top:120%;left:0;background:${c.bg};border:1px solid ${c.bd};border-radius:8px;box-shadow:0 8px 30px rgba(0,0,0,.35);padding:6px;min-width:280px;max-width:min(80vw,720px);max-height:50vh;overflow:auto;z-index:5;display:none}
#grd-ov .grd-dd-panel.open{display:block}
#grd-ov .grd-dd-item{display:flex;align-items:center;gap:8px;padding:5px 8px;font:12px ui-monospace,monospace;border-radius:6px;cursor:pointer;white-space:nowrap}
#grd-ov .grd-dd-btn{font-weight:600}
#grd-ov .grd-dd-item:hover{background:${c.bar}}
#grd-ov .grd-md{line-height:1.6;font-size:13px;word-break:break-word}
#grd-ov .grd-md h1,#grd-ov .grd-md h2,#grd-ov .grd-md h3{border-bottom:1px solid ${c.bd};padding-bottom:4px;margin:18px 0 10px}
#grd-ov .grd-md table{border-collapse:collapse;width:100%;margin:10px 0;font-size:12px}
#grd-ov .grd-md th,#grd-ov .grd-md td{border:1px solid ${c.bd};padding:6px 8px;vertical-align:top;text-align:left}
#grd-ov .grd-md th{background:${c.th}}
#grd-ov .grd-md code{background:${c.bar};padding:1px 5px;border-radius:4px;font-family:ui-monospace,monospace;font-size:.92em}
#grd-ov .grd-md pre{background:${c.bar};padding:10px;border-radius:6px;overflow:auto}
#grd-ov .grd-md ul{margin:4px 0;padding-left:18px}
#grd-ov .del{background:${c.delBg};box-shadow:inset 3px 0 0 ${c.delBd};padding-left:9px;border-radius:2px}
#grd-ov .add{background:${c.addBg};box-shadow:inset 3px 0 0 ${c.addBd};padding-left:9px;border-radius:2px}
#grd-ov .grd-btn{background:transparent;border:1px solid ${c.bd};color:${c.fg};border-radius:6px;padding:4px 12px;cursor:pointer;font:600 13px system-ui}
#grd-ov .grd-legend{color:${c.mut};font-size:12px;white-space:nowrap}
#grd-ov .grd-legend b{padding:1px 6px;border-radius:3px}
#grd-ov .grd-nav{display:inline-flex;align-items:center;gap:4px}
#grd-ov .grd-navbtn{background:transparent;border:1px solid ${c.bd};color:${c.fg};border-radius:6px;width:28px;height:26px;cursor:pointer;font:600 14px system-ui;line-height:1}
#grd-ov .grd-navbtn:hover{background:${c.bar}}
#grd-ov .grd-count{color:${c.mut};font-size:12px;min-width:42px;text-align:center}
#grd-ov .grd-flash{outline:2px solid ${c.addBd};outline-offset:2px;transition:outline-color .3s}
#grd-ov .grd-badge{display:inline-block;min-width:15px;height:16px;padding:0 4px;margin-right:6px;border-radius:8px;background:#8957e5;color:#fff;font:700 10px/16px ui-monospace,monospace;text-align:center;vertical-align:middle}
#grd-ov .grd-badge-cur{background:#e3b341;color:#1f2328;box-shadow:0 0 0 2px ${c.fg}}
/* a badge that has a counterpart on the other side is clickable; a lone
   removal/addition is dimmed so it reads as "nothing pairs with this" */
#grd-ov .grd-badge-link{cursor:pointer}
#grd-ov .grd-badge-link:hover{background:#a371f7;text-decoration:underline}
#grd-ov .grd-badge-solo{background:#6e7681}
/* blank space that keeps a one-sided change level with the other pane —
   striped, like GitHub's empty split-view rows, so it reads as "nothing here" */
#grd-ov .grd-filler{margin:0;background:repeating-linear-gradient(45deg,transparent,transparent 5px,${c.bd}55 5px,${c.bd}55 10px)}
#grd-ov td.grd-filler,#grd-ov .grd-filler td{background:repeating-linear-gradient(45deg,transparent,transparent 5px,${c.bd}55 5px,${c.bd}55 10px)}
`;
  }

  function renderCompare(files) {
    document.getElementById('grd-ov')?.remove();
    const dark = matchMedia('(prefers-color-scheme: dark)').matches;
    const style = $('style'); style.textContent = css(dark); document.head.appendChild(style);

    const body = $('div'); body.className = 'grd-body';   // single scroll container
    const panehead = $('div'); panehead.className = 'grd-panehead';
    panehead.appendChild(Object.assign($('div'), { textContent: 'Old (base)' }));
    panehead.appendChild(Object.assign($('div'), { textContent: 'New (head)' }));
    body.appendChild(panehead);

    const multi = files.length > 1;
    const blocks = [];        // { fi, path, sec, paneOld, paneNew }
    const rebuilders = [];    // per-file anchor rebuild fns
    const clearSelectors = []; // per-file "drop the row selection" fns
    const topIn = el => el.getBoundingClientRect().top - body.getBoundingClientRect().top + body.scrollTop;
    const addBadge = (el, n) => { const b = $('span', null, [String(n)]); b.className = 'grd-badge'; el.prepend(b); return b; };

    // Flash an element and bring it into view — used by the nav buttons and by a
    // badge jumping to its counterpart on the other side.
    const reveal = el => {
      el.scrollIntoView({ block: 'center' });
      el.classList.add('grd-flash');
      setTimeout(() => el.classList.remove('grd-flash'), 900);
    };

    files.forEach((file, fi) => {
      const sec = $('div'); sec.className = 'grd-fileblock'; sec.dataset.fi = fi;
      const left = renderMd(file.old), right = renderMd(file.new);
      wireAnchors(left); wireAnchors(right);
      const ua = units(left), ub = units(right);
      const { aCh, bCh, groups, pairs } = diffFlags(ua.map(keyOf), ub.map(keyOf));
      const nDel = highlight(ua, aCh, 'del', groupIndex(groups, 'a'));
      const nAdd = highlight(ub, bCh, 'add', groupIndex(groups, 'b'));

      const paneOld = $('div'); paneOld.className = 'grd-pane'; paneOld.appendChild(left);
      const paneNew = $('div'); paneNew.className = 'grd-pane'; paneNew.appendChild(right);
      const row = $('div'); row.className = 'grd-cols'; row.appendChild(paneOld); row.appendChild(paneNew);

      // GitHub-style file header: [chevron] 📄 path … [legend] [↑ n/total ↓]  (per-file nav)
      const chevron = $('button', null, ['▾']); chevron.className = 'grd-chevron'; chevron.title = 'Collapse / expand file';
      const pathEl = $('span', null, ['📄 ' + file.path]);
      const removed = $('span', 'margin-left:32px'); removed.className = 'grd-legend';
      removed.innerHTML = `<b class="del">▍removed/changed</b> ${nDel}`;
      const added = $('span', 'margin-left:28px'); added.className = 'grd-legend';
      added.innerHTML = `<b class="add">▍added/changed</b> ${nAdd}`;
      const prevBtn = $('button', null, ['↑']); prevBtn.className = 'grd-navbtn'; prevBtn.title = 'Previous change in this file';
      const nextBtn = $('button', null, ['↓']); nextBtn.className = 'grd-navbtn'; nextBtn.title = 'Next change in this file';
      const counter = $('span', null, ['0/0']); counter.className = 'grd-count';
      const nav = $('span', 'margin-left:32px', [prevBtn, counter, nextBtn]); nav.className = 'grd-nav';
      const fh = $('div', null, [chevron, pathEl, removed, added, nav]); fh.className = 'grd-file';

      // row state: one selection per file, either a full line across both panes
      // or just the old / just the new side
      let rowsO = [], rowsN = [], rowsAll = [], band = null, sel = null;
      const paintSel = () => {
        paneOld.querySelectorAll('.grd-lineno.on').forEach(n => n.classList.remove('on'));
        paneNew.querySelectorAll('.grd-lineno.on').forEach(n => n.classList.remove('on'));
        if (!band) return;
        const list = sel && (sel.side === 'o' ? rowsO : sel.side === 'n' ? rowsN : rowsAll);
        const r = list && list[sel.idx];
        if (!r) { band.style.display = 'none'; return; }
        band.style.display = '';
        band.style.top = r.top + 'px';
        band.style.height = Math.max(6, r.bottom - r.top) + 'px';
        // one side only → keep the band inside that pane's column
        const w = paneOld.offsetWidth;
        band.style.left = sel.side === 'n' ? w + 'px' : '0';
        band.style.right = sel.side === 'o' ? (row.offsetWidth - w) + 'px' : '0';
        if (r.no) r.no.classList.add('on');
      };
      const pickRow = (list, y) => {
        for (let i = 0; i < list.length; i++) if (y >= list[i].top - 2 && y <= list[i].bottom + 2) return i;
        return -1;
      };
      const setSel = next => {
        const same = sel && next && sel.side === next.side && sel.idx === next.idx;
        sel = same ? null : next;      // clicking the same line again clears it
        paintSel();
      };
      // A number picks its own side; clicking the text picks the whole line on
      // both sides. Dragging out a text selection, or clicking a link or a change
      // badge, must not be hijacked into a row selection.
      row.addEventListener('click', e => {
        const no = e.target.closest('.grd-lineno');
        if (no) {
          setSel({ side: paneOld.contains(no) ? 'o' : 'n', idx: +no.dataset.row });
          return;
        }
        if (e.target.closest('a, .grd-badge')) return;
        const s = getSelection();
        if (s && !s.isCollapsed) return;                  // user is selecting text
        const y = e.clientY - row.getBoundingClientRect().top;
        const i = pickRow(rowsAll, y);
        if (i >= 0) setSel({ side: 'both', idx: i });
      });
      const clearSel = () => { if (!sel) return false; sel = null; paintSel(); return true; };
      clearSelectors.push(clearSel);

      // per-file change navigation
      let anchors = [], idx = -1;
      const rebuild = () => {
        sec.querySelectorAll('.grd-badge').forEach(b => b.remove());
        sec.querySelectorAll('.grd-filler').forEach(f => f.remove());
        if (row.style.display !== 'none') syncVisibility(ua, ub, pairs);
        // One badge per changed line, per pane. The de-dup has to be per side:
        // the panes sit next to each other, so an old-side change and its new-side
        // counterpart share a vertical position — comparing tops across both panes
        // silently dropped every counterpart badge (1-n, 2-n … never appeared).
        const collect = (pane, cls) => {
          const list = [...pane.querySelectorAll('.' + cls)]
            .filter(el => el.offsetParent).map(el => ({ el, top: topIn(el) }))
            .sort((a, b) => a.top - b.top);
          const kept = [];
          for (const a of list) if (!kept.length || Math.abs(a.top - kept[kept.length - 1].top) > 8) kept.push(a);
          return kept;
        };
        anchors = [...collect(paneOld, 'del'), ...collect(paneNew, 'add')]
          .sort((a, b) => a.top - b.top);
        // Label a change with its hunk number plus the side: 2-o on the old
        // pane pairs with 2-n on the new one. Clicking either jumps to the
        // other, which is the quickest way to see what a change replaced.
        // Units the diff could not group fall back to a plain running number.
        anchors.forEach((a, i) => {
          const g = a.el.dataset.grdGroup;
          const side = a.el.classList.contains('del') ? 'o' : 'n';
          a.badge = addBadge(a.el, g ? g + '-' + side : i + 1);
          if (!g) return;
          const otherPane = side === 'o' ? paneNew : paneOld;
          const mate = otherPane.querySelector(`[data-grd-group="${g}"]`);
          a.badge.classList.add(mate ? 'grd-badge-link' : 'grd-badge-solo');
          a.badge.title = mate
            ? `Change ${g} — ${side === 'o' ? 'old' : 'new'} side. Click to jump to ${g}-${side === 'o' ? 'n' : 'o'}.`
            : `Change ${g} — ${side === 'o' ? 'removed, nothing replaces it' : 'added, nothing it replaces'}`;
          if (mate) a.badge.onclick = e => { e.stopPropagation(); reveal(mate); };
        });
        // Symmetry last: a badge changes the height of the line it sits on, so
        // the panes have to be measured with the badges already in place.
        // Skipped while the file is collapsed — nothing to measure then.
        if (row.style.display !== 'none') {
          alignPanes(paneOld, paneNew, ua, ub, pairs, groups);
          anchors.forEach(a => { a.top = topIn(a.el); });
          anchors.sort((a, b) => a.top - b.top);
          // rows can only be measured once the panes are aligned
          rowsO = rowsOf(ua, row); rowsN = rowsOf(ub, row);
          paintGutter(paneOld, rowsO); paintGutter(paneNew, rowsN);
          rowsAll = mergeRows(rowsO, rowsN);
          band = ensureBand(row);
          paintSel();
        }
        idx = -1;
        counter.textContent = anchors.length ? '–/' + anchors.length : '0/0';
      };
      const goTo = i => {
        if (!anchors.length) return;
        idx = (i + anchors.length) % anchors.length;
        const a = anchors[idx];
        ov.querySelectorAll('.grd-badge-cur').forEach(b => b.classList.remove('grd-badge-cur'));
        if (a.badge) a.badge.classList.add('grd-badge-cur');
        reveal(a.el);
        // Light up the counterpart too, so the pair reads as one change.
        const g = a.el.dataset.grdGroup;
        if (g) ov.querySelectorAll(`.grd-badge-link`).forEach(b => {
          if (b.textContent.split('-')[0] === g) b.classList.add('grd-badge-cur');
        });
        counter.textContent = (idx + 1) + '/' + anchors.length;
      };
      prevBtn.onclick = () => goTo(idx - 1);
      nextBtn.onclick = () => goTo(idx + 1);
      chevron.onclick = () => {
        const collapsed = row.style.display === 'none';
        row.style.display = collapsed ? '' : 'none';
        chevron.textContent = collapsed ? '▾' : '▸';
        rebuild();
      };

      sec.appendChild(fh); sec.appendChild(row);
      body.appendChild(sec);
      blocks.push({ fi, path: file.path, sec, paneOld, paneNew });
      rebuilders.push(rebuild);
    });

    // top-bar controls: [dropdown/path] [Changes only] … [Close]
    const close = $('button', null, ['✕ Close (Esc)']); close.className = 'grd-btn';
    const cb = $('input'); cb.type = 'checkbox'; cb.checked = true; cb.id = 'grd-only';
    const cbLabel = $('label', 'display:inline-flex;align-items:center;gap:5px;cursor:pointer;font-size:12px;', [cb, 'Changes only']);

    let ddBtn = null, ddPanel = null, head;
    if (multi) {
      ddBtn = $('button', null, ['📄 ' + files.length + ' .md files ▾']); ddBtn.className = 'grd-btn grd-dd-btn';
      ddPanel = $('div'); ddPanel.className = 'grd-dd-panel';
      blocks.forEach((b, i) => {
        const c = $('input'); c.type = 'checkbox'; c.checked = true;
        const item = $('label', null, [c, b.path]); item.className = 'grd-dd-item';
        c.onchange = () => { b.sec.style.display = c.checked ? '' : 'none'; rebuilders[i](); };
        ddPanel.appendChild(item);
      });
      ddBtn.onclick = e => { e.stopPropagation(); ddPanel.classList.toggle('open'); };
      head = $('span', null, [ddBtn, ddPanel]); head.className = 'grd-dd';
    } else {
      head = Object.assign($('strong'), { textContent: '📄 ' + files[0].path });
    }

    const title = $('strong', 'white-space:nowrap;flex:0 0 auto', ['\u{1F500} Git Markdown Viewer']);
    const bar = $('div', null, [title, $('span', 'width:22px'), head, $('span', 'width:22px'), cbLabel, $('span', 'flex:1'), close]);
    bar.className = 'grd-bar';

    const ov = $('div'); ov.id = 'grd-ov';
    ov.appendChild(bar); ov.appendChild(body);
    document.body.appendChild(ov);

    // file headers stick just below the sticky Old/New panehead
    const phH = panehead.offsetHeight;
    body.querySelectorAll('.grd-file').forEach(f => { f.style.top = phH + 'px'; });

    if (ddPanel) ov.addEventListener('click', e => {
      if (!ddBtn.contains(e.target) && !ddPanel.contains(e.target)) ddPanel.classList.remove('open');
    });

    const applyMode = () => {
      blocks.forEach(b => { collapse(b.paneOld, 'del', cb.checked); collapse(b.paneNew, 'add', cb.checked); });
      rebuilders.forEach(fn => fn());
    };
    cb.onchange = applyMode;
    applyMode();

    // A narrower window rewraps the text, which changes block heights and would
    // leave the two panes out of step — measure again once the resize settles.
    let rzT = 0;
    const onResize = () => { clearTimeout(rzT); rzT = setTimeout(() => rebuilders.forEach(fn => fn()), 150); };
    addEventListener('resize', onResize);

    const teardown = () => {
      ov.remove(); style.remove();
      removeEventListener('keydown', onKey);
      removeEventListener('resize', onResize);
    };
    const onKey = e => {
      if (e.key !== 'Escape') return;
      // Escape backs out of the row selection first, then closes the viewer.
      if (clearSelectors.some(fn => fn())) return;
      teardown();
    };
    close.onclick = teardown;
    addEventListener('keydown', onKey);
  }

  // ---------- data acquisition ----------
  async function fetchText(url) {
    const r = await fetch(url, { credentials: 'include' });
    if (!r.ok) throw new Error(url + ' → HTTP ' + r.status);
    return r.text();
  }

  // Get a file's content at a commit via the same-origin blob?plain=1 page and its
  // embedded rawLines. (The /raw/ and .diff endpoints redirect cross-origin and are
  // blocked by CORS/CSP; blob?plain=1 stays on github.com.)
  async function getFileAtSha(owner, repo, sha, path) {
    const html = await fetchText(`/${owner}/${repo}/blob/${sha}/${path}?plain=1`);
    const doc = new DOMParser().parseFromString(html, 'text/html');
    for (const s of doc.querySelectorAll('script[type="application/json"]')) {
      try {
        const j = JSON.parse(s.textContent);
        const lines = findRawLines(j);
        if (lines) return lines.join('\n');
      } catch (e) {}
    }
    throw new Error('could not read file content at ' + sha.slice(0, 7));
  }
  function findRawLines(obj) {
    let found = null;
    (function walk(o) {
      if (found || !o || typeof o !== 'object') return;
      if (Array.isArray(o.rawLines) && o.rawLines.every(x => typeof x === 'string')) { found = o.rawLines; return; }
      for (const k in o) walk(o[k]);
    })(obj);
    return found;
  }

  function deepFindOids(obj, wantBase) {
    // scan embedded React JSON for base/head commit oids
    const hexes = { base: null, head: null };
    const re = /^[0-9a-f]{40}$/;
    (function walk(o) {
      if (!o || typeof o !== 'object') return;
      for (const k in o) {
        const v = o[k];
        if (typeof v === 'string' && re.test(v)) {
          const lk = k.toLowerCase();
          if (/base/.test(lk) && /oid|sha/.test(lk)) hexes.base = hexes.base || v;
          if (/head/.test(lk) && /oid|sha/.test(lk)) hexes.head = hexes.head || v;
        } else if (typeof v === 'object') walk(v);
      }
    })(obj);
    return hexes;
  }

  // Discover changed .md paths from the page (embedded JSON first, then DOM),
  // without hitting the cross-origin .diff endpoint.
  function getMdPaths() {
    const set = new Set();
    const reMd = /^[\w./-]+\.md$/;
    for (const s of document.querySelectorAll('script[type="application/json"]')) {
      let j; try { j = JSON.parse(s.textContent); } catch (e) { continue; }
      (function walk(o) {
        if (!o || typeof o !== 'object') return;
        for (const k in o) {
          const v = o[k];
          if (typeof v === 'string' && v.includes('/') && reMd.test(v)) set.add(v);
          else if (v && typeof v === 'object') walk(v);
        }
      })(j);
    }
    // DOM fallbacks
    for (const e of document.querySelectorAll('[title],[data-path],[data-file-path],[data-tagsearch-path]')) {
      const t = e.getAttribute('data-path') || e.getAttribute('data-file-path') ||
                e.getAttribute('data-tagsearch-path') || e.getAttribute('title') || '';
      if (t.includes('/') && reMd.test(t)) set.add(t);
    }
    return [...set];
  }

  function scanDocForShas(root) {
    const hex = v => typeof v === 'string' && /^[0-9a-f]{40}$/.test(v);
    // Prefer the exact PR-changes route data — avoids grabbing a stale/wrong hash
    // (e.g. mergeBaseOid, a comment's oid, or a previous PR left over by GitHub's SPA).
    for (const s of root.querySelectorAll('script[type="application/json"]')) {
      let j; try { j = JSON.parse(s.textContent); } catch (e) { continue; }
      const r = j && j.payload && j.payload.pullRequestsChangesRoute;
      const fd = r && r.comparison && (r.comparison.fullDiff || r.comparison);
      if (fd && hex(fd.baseOid) && hex(fd.headOid)) return { base: fd.baseOid, head: fd.headOid };
      const pr = r && r.pullRequest && r.pullRequest.comparison;
      if (pr && hex(pr.baseOid) && hex(pr.headOid)) return { base: pr.baseOid, head: pr.headOid };
    }
    return null;
  }

  async function getShas(owner, repo, num) {
    // The current page can hold the WRONG pair: a "changes since last review" range
    // (…/changes/<sha1>..<sha2>) or stale SPA data — those may even point at
    // pre-rebase commits (old content, no fetch error!). So always fetch the
    // canonical full-diff Changes page fresh and read base/head from THAT.
    try {
      const html = await fetchText(`/${owner}/${repo}/pull/${num}/changes`);
      const doc = new DOMParser().parseFromString(html, 'text/html');
      const s = scanDocForShas(doc);
      if (s) return s;
    } catch (e) {}
    // fallback: current document (may be a ranged/stale view — hard-reload if wrong)
    const s = scanDocForShas(document);
    if (s) return s;
    let base = null, head = null;
    for (const sc of document.querySelectorAll('script[type="application/json"]')) {
      try { const f = deepFindOids(JSON.parse(sc.textContent)); base = base || f.base; head = head || f.head; } catch (e) {}
    }
    return { base, head };
  }

  // Modal error box with a "Reload page" button (used for hash / stale-data errors).
  function errDialog(title, msg) {
    document.getElementById('grd-err')?.remove();
    const dark = matchMedia('(prefers-color-scheme: dark)').matches;
    const bg = dark ? '#161b22' : '#fff', fg = dark ? '#e6edf3' : '#1f2328';
    const bd = dark ? '#30363d' : '#d0d7de', mut = dark ? '#8b949e' : '#57606a';
    const wrap = $('div'); wrap.id = 'grd-err';
    wrap.setAttribute('style', 'position:fixed;inset:0;z-index:2147483647;background:rgba(0,0,0,.5);display:flex;align-items:center;justify-content:center;font:14px system-ui');
    const card = $('div', 'background:' + bg + ';color:' + fg + ';border:1px solid ' + bd + ';border-radius:12px;max-width:460px;width:90%;padding:20px;box-shadow:0 12px 40px rgba(0,0,0,.4)');
    card.appendChild(Object.assign($('div'), { textContent: '⚠️ ' + title, style: 'font-weight:600;font-size:15px;margin-bottom:8px' }));
    const body = $('div', 'color:' + mut + ';white-space:pre-wrap;line-height:1.5;margin-bottom:16px'); body.textContent = msg;
    card.appendChild(body);
    const reload = $('button', 'background:#1f6feb;color:#fff;border:0;border-radius:6px;padding:7px 14px;font:600 13px system-ui;cursor:pointer', ['🔄 Reload page']);
    reload.onclick = () => location.reload();
    const close = $('button', 'background:transparent;color:' + fg + ';border:1px solid ' + bd + ';border-radius:6px;padding:7px 14px;font:600 13px system-ui;cursor:pointer', ['Close']);
    close.onclick = () => wrap.remove();
    const btns = $('div', 'display:flex;gap:8px;justify-content:flex-end', [close, reload]);
    card.appendChild(btns);
    wrap.appendChild(card);
    wrap.addEventListener('click', e => { if (e.target === wrap) wrap.remove(); });
    document.body.appendChild(wrap);
    reload.focus();
  }

  // Loading overlay: shared spinner (shared/spinner.js, injected before this file).
  const showLoading = () => globalThis.GKSpin.show('Git Markdown Viewer \u2014 loading data\u2026');
  const hideLoading = () => globalThis.GKSpin.hide();

  async function main() {
    if (typeof window.__GRD_OLD__ === 'string' && typeof window.__GRD_NEW__ === 'string') {
      renderCompare([{ path: window.__GRD_PATH__ || 'test.md', old: window.__GRD_OLD__, new: window.__GRD_NEW__ }]);
      return;
    }
    if (Array.isArray(window.__GRD_FILES__)) { renderCompare(window.__GRD_FILES__); return; }

    const m = location.pathname.match(/^\/([^/]+)\/([^/]+)\/pull\/(\d+)/);
    if (!m) { alert('Open a Pull Request page first (…/pull/<n>/files or /changes), then run again.'); return; }
    const [, owner, repo, prNum] = m;

    showLoading();
    try {
    const { base, head } = await getShas(owner, repo, prNum);
    if (!base || !head) {
      errDialog('Could not read the PR commit hash',
        'Could not read the PR base/head commit on this page.\n' +
        'GitHub soft-navigation can leave stale data — reload the Files-changed page and run again.\n\n' +
        'base = ' + base + '\nhead = ' + head);
      return;
    }
    console.log('[git-md-viewer] comparing ' + base.slice(0, 7) + '…' + head.slice(0, 7));

    let mdPaths = getMdPaths();
    if (!mdPaths.length) {
      hideLoading();
      const p = prompt('No changed .md file detected. Paste the file path (copy it from the file header on the page):', '');
      if (!p) return;
      mdPaths = [p.trim()];
      showLoading();
    }

    // Load every changed .md (both versions), skip any that fail.
    const results = await Promise.all(mdPaths.map(async path => {
      try {
        const [oldMd, newMd] = await Promise.all([
          getFileAtSha(owner, repo, base, path),
          getFileAtSha(owner, repo, head, path),
        ]);
        return { path, old: oldMd, new: newMd };
      } catch (e) {
        console.warn('[gh-render-diff] skip ' + path + ': ' + e.message);
        return null;
      }
    }));
    const files = results.filter(Boolean);
    if (!files.length) {
      errDialog('Could not load .md file content',
        'Could not load any .md file content — the commit hash may be stale.\n' +
        'Reload the Files-changed page and run again.');
      return;
    }
    if (files.length < mdPaths.length) {
      console.warn('[gh-render-diff] loaded ' + files.length + '/' + mdPaths.length + ' .md files');
    }
    renderCompare(files);
    } finally { hideLoading(); }
  }

  main();
})();
