// Content script declared in manifest.json for github.com. On a PR
// "Files changed" page (…/pull/<n>/changes or /files) it counts the changed
// .md files and:
//   - shows a floating "View .md diff (N)" button (bottom-right) that asks the
//     background to inject the Git Markdown Viewer,
//   - reports the count to the background ({type:"gkMdCount"}), which drives
//     the toolbar-icon badge and the context-menu visibility.
// GitHub is a SPA, so the URL is polled — soft-navigations (history.pushState)
// fire no reliable page event a content script can hook from its own world.
(function () {
    "use strict";
    const api = globalThis.browser ?? globalThis.chrome;
    const PR_RE = /^https:\/\/github\.com\/[^/]+\/[^/]+\/pull\/\d+\/(changes|files)([/?#]|$)/;
    const reMd = /\.(md|markdown)$/i;
    let lastUrl = null;
    let btn = null;

    // Collect changed-file paths that look like .md from embedded React JSON.
    function collectFromDoc(root, set) {
        for (const s of root.querySelectorAll('script[type="application/json"]')) {
            if (!/\.(md|markdown)"/i.test(s.textContent)) continue;
            let j;
            try { j = JSON.parse(s.textContent); } catch (e) { continue; }
            (function walk(o) {
                if (!o || typeof o !== "object") return;
                for (const k in o) {
                    const v = o[k];
                    if ((k === "path" || k === "filePath" || k === "newPath" || k === "oldPath") &&
                        typeof v === "string" && reMd.test(v)) set.add(v);
                    else walk(v);
                }
            })(j);
        }
    }

    async function countMd() {
        const set = new Set();
        try {
            collectFromDoc(document, set);
            if (!set.size) {
                // DOM fallback (noisier attributes → require a path-like "/")
                for (const e of document.querySelectorAll("[data-path],[data-file-path],[data-tagsearch-path]")) {
                    const t = e.getAttribute("data-path") || e.getAttribute("data-file-path") ||
                              e.getAttribute("data-tagsearch-path") || "";
                    if (t.includes("/") && reMd.test(t)) set.add(t);
                }
            }
            if (!set.size) {
                // Soft-navigation: the live document still embeds the PREVIOUS
                // route's data — fetch the canonical full-diff page and scan that.
                const m = location.pathname.match(/^\/([^/]+)\/([^/]+)\/pull\/(\d+)/);
                if (m) {
                    const res = await fetch(`/${m[1]}/${m[2]}/pull/${m[3]}/changes`, { credentials: "include" });
                    if (res.ok) collectFromDoc(new DOMParser().parseFromString(await res.text(), "text/html"), set);
                }
            }
        } catch (e) {}
        return set.size;
    }

    function send(msg) {
        try { Promise.resolve(api.runtime.sendMessage(msg)).catch(() => {}); } catch (e) {}
    }

    function ensureBtn(count) {
        if (!btn) {
            btn = document.createElement("button");
            btn.id = "gk-md-btn";
            btn.setAttribute("style",
                "position:fixed;right:24px;bottom:24px;z-index:2147483000;" +
                "background:#1f6feb;color:#fff;border:0;border-radius:999px;" +
                "padding:10px 18px;font:600 13px system-ui,-apple-system,sans-serif;" +
                "cursor:pointer;box-shadow:0 6px 20px rgba(0,0,0,.3)");
            btn.addEventListener("mouseenter", () => { btn.style.background = "#1a5fd0"; });
            btn.addEventListener("mouseleave", () => { btn.style.background = "#1f6feb"; });
            btn.onclick = () => send({ type: "gkRunGitMdViewer" });
            document.body.appendChild(btn);
        }
        btn.textContent = "\u{1F4C4} View .md diff (" + count + ")";
        btn.style.display = "";
    }

    function hideBtn() { if (btn) btn.style.display = "none"; }

    async function check() {
        if (typeof window.__GK_PR_TEST__ === "number") {          // test hook
            window.__GK_PR_TEST__ > 0 ? ensureBtn(window.__GK_PR_TEST__) : hideBtn();
            return;
        }
        const url = location.href;
        if (url === lastUrl) return;
        lastUrl = url;
        if (!PR_RE.test(url)) { hideBtn(); send({ type: "gkMdCount", count: 0 }); return; }
        const count = await countMd();
        if (location.href !== url) return; // navigated away while counting
        send({ type: "gkMdCount", count });
        count > 0 ? ensureBtn(count) : hideBtn();
    }

    setInterval(check, 800);
    check();
})();
