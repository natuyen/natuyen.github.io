// Injected into the active Garoon tab. Scrapes the comments of the schedule
// detail page (#schedule_comments) and returns them oldest-first, joined by a
// separator. Clipboard writing is done back in the popup (the focused surface).
// Classic script (usable BOTH as a <script src> in the popup and via
// scripting.executeScript({files}) from the background) — registers itself
// on globalThis.GKScrape. No ES import/export on purpose.
(function () {
    "use strict";
    function scrapeScheduleComments() {
        const container = document.getElementById("schedule_comments");
        if (!container) {
            return { ok: false, error: "Schedule comments not found. Open a Garoon schedule detail page." };
        }

        const comments = container.querySelectorAll("pre.format_contents");
        if (!comments.length) {
            return { ok: false, error: "No comments found on this schedule." };
        }

        // DOM lists comments newest-first; iterate in reverse for oldest-first output.
        let output = "";
        for (let i = comments.length - 1; i >= 0; i--) {
            output += comments[i].innerText.trim() + "\n-------------------------\n";
        }

        return { ok: true, text: output, count: comments.length };
    }

    (globalThis.GKScrape = globalThis.GKScrape || {}).scrapeScheduleComments = scrapeScheduleComments;
})();
