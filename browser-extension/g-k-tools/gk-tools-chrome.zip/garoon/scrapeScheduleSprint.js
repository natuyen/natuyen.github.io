// Injected into the active Garoon group/week schedule tab. Lists event titles
// grouped by day, with per-event hours, a per-day total, and a grand total:
//   * Thu, July 23 (2.75h)
//      * 🍜 Ramen 🍜 Daily Scrum (a Tuyên) (0.25h)
//   ...
//   Total: 12.50h
// Clipboard writing is done back in the popup.
// Classic script (usable BOTH as a <script src> in the popup and via
// scripting.executeScript({files}) from the background) — registers itself
// on globalThis.GKScrape. No ES import/export on purpose.
(function () {
    "use strict";
    function scrapeScheduleSprint() {
        // Map each date (YYYY-MM-DD) to its header label ("Thu, July 23").
        const dateLabels = {};
        document.querySelectorAll('a[href*="group_day.csp"]').forEach((a) => {
            const m = (a.getAttribute("href") || "").match(/bdate=(\d{4}-\d{2}-\d{2})/);
            if (m) dateLabels[m[1]] = a.textContent.trim();
        });

        const toMinutes = (t) => {
            const [h, m] = t.split(":");
            return (parseInt(h, 10) || 0) * 60 + (parseInt(m, 10) || 0);
        };

        // Collect events (title + duration in minutes) grouped by day column.
        const byDate = {};
        document.querySelectorAll("td.s_user_week").forEach((td) => {
            const dateEl = td.querySelector("[data-date]");
            let date = dateEl ? dateEl.getAttribute("data-date") : null;
            if (!date) {
                const m = (td.getAttribute("rel") || "").match(/bdate=(\d{4}-\d{2}-\d{2})/);
                date = m ? m[1] : null;
            }
            if (!date) return;
            if (!byDate[date]) byDate[date] = [];

            td.querySelectorAll(".normalEventElement").forEach((ev) => {
                const titleEl = ev.querySelector(".groupWeekEventTitle");
                if (!titleEl) return; // e.g. banners have no title block
                // Clean the title: drop trailing "[...]" room tags and the leading
                // "🍜 Ramen 🍜" prefix (keep leading tags like [Ramen]).
                const title = titleEl.innerText.trim()
                    .replace(/(\s*\[[^\]]*\])+\s*$/, "")
                    .replace(/^\s*🍜\s*Ramen\s*🍜\s*[-–—]?\s*/, "")
                    .trim();
                if (!title) return;

                const timeEl = ev.querySelector(".listTime");
                const timeStr = timeEl ? timeEl.innerText.trim() : "";
                let minutes = 0;
                if (timeStr) {
                    const parts = timeStr.split("-");
                    if (parts.length === 2) minutes = toMinutes(parts[1]) - toMinutes(parts[0]);
                }
                if (minutes < 0) minutes = 0;

                byDate[date].push({ title, minutes });
            });
        });

        const dates = Object.keys(byDate).filter((d) => byDate[d].length).sort();
        if (!dates.length) {
            return { ok: false, error: "No schedule events found. Open a Garoon group/week schedule view." };
        }

        const hours = (min) => (min / 60).toFixed(2) + "h";
        const blocks = [];
        let grandMinutes = 0;
        let total = 0;
        dates.forEach((date) => {
            const events = byDate[date];
            const dayMinutes = events.reduce((sum, e) => sum + e.minutes, 0);
            grandMinutes += dayMinutes;
            let block = `- ${dateLabels[date] || date} (${hours(dayMinutes)})\n`;
            events.forEach((e) => {
                block += `   + ${e.title} (${hours(e.minutes)})\n`;
                total++;
            });
            blocks.push(block);
        });
        // Blank line between days for readability.
        const output = blocks.join("\n") + `\nTotal: ${hours(grandMinutes)}`;

        return { ok: true, text: output, count: total };
    }

    (globalThis.GKScrape = globalThis.GKScrape || {}).scrapeScheduleSprint = scrapeScheduleSprint;
})();
