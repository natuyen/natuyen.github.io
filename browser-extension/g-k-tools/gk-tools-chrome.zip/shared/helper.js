// Shared helpers used by the extension popup / handlers.

// Cross-browser WebExtension API namespace: Firefox exposes promise-based
// `browser.*`, Chrome exposes promise-based `chrome.*`. Prefer `browser`.
export const api = globalThis.browser ?? globalThis.chrome;

/**
 * Inject `func` into the active tab and return its result.
 * @param {Function} func  Function serialized and executed on the page.
 * @param {Array}   [args] Arguments passed to `func`.
 */
export async function runOnActiveTab(func, args = []) {
    const [tab] = await api.tabs.query({ active: true, currentWindow: true });
    const [res] = await api.scripting.executeScript({
        target: { tabId: tab.id },
        func,
        args,
    });
    return res?.result;
}

/**
 * Write text to the clipboard. Call this from the popup (a focused, user-
 * activated surface) — writing from an injected page script is unreliable.
 */
export async function copyToClipboard(text) {
    await navigator.clipboard.writeText(text);
}

/** Open an extension-bundled page (e.g. a tool) in a new browser tab. */
export function openExtensionPage(path) {
    return api.tabs.create({ url: api.runtime.getURL(path) });
}

/**
 * Inject a shared scraper FILE into the active tab, then call the function it
 * registered on globalThis.GKScrape and return its result. Needed because
 * `executeScript({func})` serializes only the function body — a scraper that
 * relies on helpers in its own module scope must be injected as a file instead.
 * @param {string} file    e.g. "shared/doclinks.js"
 * @param {string} fnName  key on globalThis.GKScrape, e.g. "collectDocLinks"
 * @param {Array}  [args]
 */
export async function callSharedScraper(file, fnName, args = []) {
    const [tab] = await api.tabs.query({ active: true, currentWindow: true });
    if (!tab || !tab.id) throw new Error('No active tab.');
    await api.scripting.executeScript({ target: { tabId: tab.id }, files: [file] });
    const [res] = await api.scripting.executeScript({
        target: { tabId: tab.id },
        func: (name, a) => globalThis.GKScrape[name].apply(null, a || []),
        args: [fnName, args],
    });
    return { tabId: tab.id, result: res && res.result };
}

/**
 * Inject extension-bundled script FILE(s) into the active tab (content script:
 * exempt from the page CSP, fetches with the page cookies). Files run in the
 * given order, sharing one isolated world (a lib file can define globals for
 * the next file).
 * @param {string|string[]} files Path(s) inside the extension, e.g. "tools/x.js".
 * @param {RegExp} [urlPattern]   Required active-tab URL; rejects when unmatched.
 * @returns {Promise<{ok:boolean, error?:string}>}
 */
export async function runFileOnActiveTab(files, urlPattern) {
    const [tab] = await api.tabs.query({ active: true, currentWindow: true });
    if (!tab || !tab.id) return { ok: false, error: 'No active tab.' };
    if (urlPattern && !urlPattern.test(tab.url || '')) return { ok: false, error: 'wrong-page' };
    await api.scripting.executeScript({
        target: { tabId: tab.id },
        files: Array.isArray(files) ? files : [files],
    });
    return { ok: true };
}

/**
 * Update the popup status line (#status).
 * @param {string} msg
 * @param {'ok'|'err'} [kind]
 */
export function setStatus(msg, kind) {
    const el = document.getElementById('status');
    if (!el) return;
    el.textContent = msg;
    el.className = 'status' + (kind ? ' ' + kind : '');
}

/**
 * Scrape the active tab, copy the result to the clipboard, and report progress
 * on the status line. `scraper` must return `{ ok, text, ... }` on success or
 * `{ ok: false, error }` on failure.
 * @param {Function} scraper           Function injected into the page.
 * @param {object}   [opts]
 * @param {Array}    [opts.args]       Arguments for the scraper.
 * @param {string}   [opts.loading]    Status shown while running.
 * @param {Function} [opts.success]    (data) => success message string.
 */
export async function copyFromActiveTab(scraper, { args = [], loading = 'Working…', success } = {}) {
    setStatus(loading);
    try {
        const data = await runOnActiveTab(scraper, args);
        if (!data || !data.ok) {
            setStatus(data?.error || 'Could not read data.', 'err');
            return;
        }
        await copyToClipboard(data.text);
        setStatus(typeof success === 'function' ? success(data) : 'Copied ✓', 'ok');
    } catch (error) {
        console.error('copyFromActiveTab error:', error);
        setStatus('Error: ' + (error?.message || error), 'err');
    }
}

/**
 * Wire up a map of { elementId: clickHandler } once the DOM is ready.
 * Warns for any id that is missing from the popup markup.
 */
export function registerHandlers(handlers) {
    document.addEventListener('DOMContentLoaded', () => {
        for (const [id, handler] of Object.entries(handlers)) {
            const el = document.getElementById(id);
            if (el) el.onclick = handler;
            else console.warn(`Element with id '${id}' not found`);
        }
    });
}
