// Collects every .md / .markdown / .txt / .text / .log document reachable from
// the current page, so the Markdown Text Viewer can offer a file picker.
// Classic script self-registering on globalThis.GKScrape — the SAME file the
// popup loads with a <script src> and the background injects.
//
// Plain <a href> scanning is not enough on a GitHub Pull Request: the file names
// in the diff and in the left-hand file tree are anchors like "#diff-<hash>"
// that only scroll the page, so nothing usable would be found. There, the
// changed paths are read from GitHub's embedded payload and turned into real
// blob URLs at the PR's head commit — the version the PR actually proposes.
(function () {
    "use strict";

    const RE_DOC = /\.(md|markdown|txt|text|log)(?:[?#]|$)/i;
    const RE_PR = /^\/([^/]+)\/([^/]+)\/pull\/(\d+)/;
    const isHex40 = (v) => typeof v === "string" && /^[0-9a-f]{40}$/.test(v);

    function fileNameOf(href) {
        const file = href.split(/[?#]/)[0].replace(/\/+$/, "").split("/").pop();
        try { return decodeURIComponent(file); } catch (e) { return file; }
    }

    // --- plain anchors on the page ------------------------------------------
    function fromAnchors(seen) {
        for (const a of document.querySelectorAll("a[href]")) {
            const href = a.href;
            if (!href || !/^https?:|^file:/i.test(href) || !RE_DOC.test(href)) continue;
            if (seen.has(href)) continue;
            let name = (a.textContent || "").replace(/\s+/g, " ").trim();
            const file = fileNameOf(href);
            if (!name || name.length > 90) name = file;
            seen.set(href, { href, name, file });
        }
    }

    // --- GitHub PR: changed docs at the head commit -------------------------
    function scanPayload(root) {
        const out = { head: null, paths: [] };
        for (const s of root.querySelectorAll('script[type="application/json"]')) {
            let j;
            try { j = JSON.parse(s.textContent); } catch (e) { continue; }
            const r = j && j.payload && j.payload.pullRequestsChangesRoute;
            const fd = r && r.comparison && (r.comparison.fullDiff || r.comparison);
            if (fd && isHex40(fd.headOid)) out.head = fd.headOid;
            (function walk(o) {
                if (!o || typeof o !== "object") return;
                for (const k in o) {
                    const v = o[k];
                    if ((k === "path" || k === "filePath" || k === "newPath") &&
                        typeof v === "string" && RE_DOC.test(v)) {
                        if (!out.paths.includes(v)) out.paths.push(v);
                    } else walk(v);
                }
            })(j);
            if (out.head && out.paths.length) break;
        }
        return out;
    }

    async function fromPullRequest(seen) {
        const m = location.pathname.match(RE_PR);
        if (!m) return;
        const [, owner, repo, num] = m;

        let info = scanPayload(document);
        // A soft-navigation leaves the previous route's payload in the document,
        // so fetch the canonical full-diff page when anything is missing.
        if (!info.head || !info.paths.length) {
            try {
                const res = await fetch(`/${owner}/${repo}/pull/${num}/changes`, { credentials: "include" });
                if (res.ok) {
                    const fresh = scanPayload(new DOMParser().parseFromString(await res.text(), "text/html"));
                    info = { head: info.head || fresh.head, paths: info.paths.length ? info.paths : fresh.paths };
                }
            } catch (e) {}
        }
        if (!info.head || !info.paths.length) return;

        for (const path of info.paths) {
            const href = `${location.origin}/${owner}/${repo}/blob/${info.head}/${path}`;
            if (seen.has(href)) continue;
            seen.set(href, { href, name: path, file: fileNameOf(path) });
        }
    }

    // GitHub's file anchors are "#diff-<sha256 of the file path>" (verified
    // against a real PR). That makes a file-tree link resolvable: hash the
    // changed paths and compare. Falls back to reading a /blob/ link out of the
    // diff container, in case GitHub ever changes the scheme.
    async function sha256Hex(text) {
        const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text));
        return [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, "0")).join("");
    }

    async function resolveDiffAnchor(url) {
        const m = location.pathname.match(RE_PR);
        const hash = (String(url).split("#")[1] || "").replace(/^diff-/, "");
        if (!m || !/^[0-9a-f]{32,64}$/i.test(hash)) return null;

        const { links } = await collectDocLinks();          // PR docs as blob URLs
        for (const l of links) {
            try { if ((await sha256Hex(l.name)).toLowerCase() === hash.toLowerCase()) return l.href; } catch (e) {}
        }
        // Fallback: the diff container may itself hold a link to the blob.
        const box = document.getElementById("diff-" + hash) || document.getElementById(hash);
        const a = box && box.querySelector('a[href*="/blob/"]');
        if (a && RE_DOC.test(a.href)) return a.href;
        return null;
    }

    async function collectDocLinks() {
        const seen = new Map(); // href -> { href, name, file }
        try {
            fromAnchors(seen);
            if (location.hostname === "github.com") await fromPullRequest(seen);
        } catch (e) {}
        return { ok: true, links: [...seen.values()] };
    }

    const GK = (globalThis.GKScrape = globalThis.GKScrape || {});
    GK.collectDocLinks = collectDocLinks;
    GK.resolveDiffAnchor = resolveDiffAnchor;
})();
