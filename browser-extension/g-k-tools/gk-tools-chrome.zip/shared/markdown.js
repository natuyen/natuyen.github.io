// Shared compact Markdown parser (no external deps) — the single copy used by
// both tools/md-viewer.js (viewer page) and tools/git-md-viewer.js (PR diff,
// injected as a content script together with this file).
//
// Classic script on purpose (NOT an ES module): it must load both via a plain
// <script src> in md-viewer.html and via scripting.executeScript({files}), and
// the two runtimes disagree on module support there. Exposes `globalThis.GKMD`.
//
// Inline code is protected with the \uE000/\uE001 private-use sentinels (kept
// as ESCAPES in this source, never raw chars): they cannot occur in real text,
// unlike a bare " N " which would swallow numbers ("max 255 chars").
(function () {
  "use strict";

  function escapeHtml(s) {
    return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  }

  function inline(text) {
    // images  ![alt](src)
    text = text.replace(/!\[([^\]]*)\]\(([^)\s]+)(?:\s+"[^"]*")?\)/g,
      (_, alt, src) => `<img src="${src}" alt="${escapeHtml(alt)}">`);
    // links  [text](href)
    // In-page "#anchor" links stay in the document (no target=_blank, which
    // would pointlessly open a new tab for a same-page jump).
    text = text.replace(/\[([^\]]+)\]\(([^)\s]+)(?:\s+"[^"]*")?\)/g,
      (_, t, href) => href.charAt(0) === "#"
        ? `<a href="${href}">${t}</a>`
        : `<a href="${href}" target="_blank" rel="noopener noreferrer">${t}</a>`);
    // bold + italic
    text = text.replace(/\*\*\*([^*]+)\*\*\*/g, "<strong><em>$1</em></strong>");
    text = text.replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>");
    text = text.replace(/\b__([^_]+)__\b/g, "<strong>$1</strong>");
    text = text.replace(/\*([^*]+)\*/g, "<em>$1</em>");
    text = text.replace(/(^|[\s(])_([^_]+)_(?=[\s).,!?]|$)/g, "$1<em>$2</em>");
    // strikethrough
    text = text.replace(/~~([^~]+)~~/g, "<del>$1</del>");
    // autolink bare URLs
    text = text.replace(/(^|[\s])(https?:\/\/[^\s<]+)/g,
      (_, pre, url) => `${pre}<a href="${url}" target="_blank" rel="noopener noreferrer">${url}</a>`);
    return text;
  }

  // inline code is protected before other inline processing
  function inlineWithCode(text) {
    const codes = [];
    text = text.replace(/`([^`]+)`/g, (_, c) => {
      codes.push(`<code>${escapeHtml(c)}</code>`);
      return "\uE000" + (codes.length - 1) + "\uE001";
    });
    // Backslash-escaped punctuation ("HKEY\_LOCAL\_MACHINE") is parked behind a
    // sentinel before anything else runs: the character has to be invisible to
    // the emphasis rules below, and only then may the backslash be dropped. A
    // backslash before a non-punctuation character is literal, per Markdown, so
    // \SOFTWARE keeps its backslash.
    const esc = [];
    text = text.replace(/\\([!-\/:-@\[-`{-~])/g, (_, ch) => {
      esc.push(ch);
      return "\uE002" + (esc.length - 1) + "\uE003";
    });
    text = escapeHtml(text).replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&amp;/g, "&");
    text = breakGluedBullets(inline(text));
    return text.replace(/\uE002(\d+)\uE003/g, (_, i) => escapeHtml(esc[+i]))
               .replace(/\uE000(\d+)\uE001/g, (_, i) => codes[+i]);
  }

  // Spec cells embed multi-line HTML; a bullet ("- item") is sometimes glued
  // straight onto the previous line with no <br> (e.g. when an item was appended
  // in a diff), so it renders on the same line. Insert a break before such a
  // glued bullet. Only fires on `<nonspace>- <nonspace>` (a real bullet), so
  // numeric ranges ("14.0-14.5", no trailing space) and " - " dashes (space
  // before) stay untouched, and it never doubles an existing break (a ">"
  // before the hyphen is excluded).
  function breakGluedBullets(text) {
    return text.replace(/([^\s>*_-])-[ \t]+(?=\S)/g, "$1<br>- ");
  }

  // GitHub-compatible heading slug: drop punctuation/symbols, lowercase,
  // spaces -> dashes. Keeps letters (any script), digits, "_" and "-", so
  // "Loading the libraries (\u203B1)" -> "loading-the-libraries-1", matching the
  // anchors in a hand-written markdown TOC.
  function slugify(text) {
    return String(text).trim().toLowerCase()
      .replace(/[^\p{L}\p{N}\s_-]/gu, "")
      // One dash per whitespace char, NOT per run: that is what GitHub does, so
      // "Admin \u2014 Add" (em dash dropped, two spaces left) becomes
      // "admin--add" and a TOC copied from GitHub still resolves.
      .replace(/\s/g, "-");
  }

  function parseMarkdown(src) {
    const lines = src.replace(/\r\n?/g, "\n").split("\n");
    let html = "";
    let i = 0;

    function listBlock(ordered) {
      const tag = ordered ? "ol" : "ul";
      let out = `<${tag}>`;
      const re = ordered ? /^(\s*)\d+\.\s+(.*)$/ : /^(\s*)[-*+]\s+(.*)$/;
      while (i < lines.length && re.test(lines[i])) {
        let m = lines[i].match(re);
        let item = m[2];
        // task list
        let checkbox = "";
        const tm = item.match(/^\[([ xX])\]\s+(.*)$/);
        if (tm) {
          checkbox = `<input type="checkbox" disabled ${tm[1].toLowerCase() === "x" ? "checked" : ""}>`;
          item = tm[2];
        }
        out += `<li>${checkbox}${inlineWithCode(item)}</li>`;
        i++;
      }
      return out + `</${tag}>`;
    }

    while (i < lines.length) {
      const line = lines[i];

      // blank
      if (/^\s*$/.test(line)) { i++; continue; }

      // fenced code
      const fence = line.match(/^\s*```+\s*(\S*)/);
      if (fence) {
        i++;
        let code = "";
        while (i < lines.length && !/^\s*```+\s*$/.test(lines[i])) { code += lines[i] + "\n"; i++; }
        i++;
        const cls = fence[1] ? ` class="language-${fence[1]}"` : "";
        html += `<pre><code${cls}>${escapeHtml(code.replace(/\n$/, ""))}</code></pre>`;
        continue;
      }

      // heading
      const h = line.match(/^(#{1,6})\s+(.*)$/);
      if (h) {
        const lv = h[1].length;
        let raw = h[2].replace(/\s+#+\s*$/, "");
        // Docusaurus-style explicit anchor: "## Title {#custom-id}" — strip it
        // from the visible text and use it as the id (spec files rely on these
        // when the auto-slug would not match their hand-written TOC).
        let id = "";
        const ex = raw.match(/\s*\{#([^}]+)\}\s*$/);
        if (ex) { id = ex[1].trim(); raw = raw.slice(0, ex.index); }
        else id = slugify(raw);
        html += `<h${lv}${id ? ` id="${escapeHtml(id).replace(/"/g, "&quot;")}"` : ""}>` +
                `${inlineWithCode(raw)}</h${lv}>`;
        i++; continue;
      }

      // hr
      if (/^\s*([-*_])(\s*\1){2,}\s*$/.test(line)) { html += "<hr>"; i++; continue; }

      // blockquote
      if (/^\s*>/.test(line)) {
        let quote = "";
        while (i < lines.length && /^\s*>/.test(lines[i])) { quote += lines[i].replace(/^\s*>\s?/, "") + "\n"; i++; }
        html += `<blockquote>${parseMarkdown(quote)}</blockquote>`;
        continue;
      }

      // table
      if (/\|/.test(line) && i + 1 < lines.length && /^\s*\|?[\s:|-]+\|?\s*$/.test(lines[i + 1]) && /-/.test(lines[i + 1])) {
        const splitRow = r => r.replace(/^\s*\|/, "").replace(/\|\s*$/, "").split("|").map(c => c.trim());
        const headers = splitRow(line);
        const aligns = splitRow(lines[i + 1]).map(c => {
          const l = c.startsWith(":"), r = c.endsWith(":");
          return l && r ? "center" : r ? "right" : l ? "left" : "";
        });
        i += 2;
        let t = "<table><thead><tr>";
        headers.forEach((hd, idx) => t += `<th${aligns[idx] ? ` style="text-align:${aligns[idx]}"` : ""}>${inlineWithCode(hd)}</th>`);
        t += "</tr></thead><tbody>";
        while (i < lines.length && /\|/.test(lines[i]) && !/^\s*$/.test(lines[i])) {
          const cells = splitRow(lines[i]);
          t += "<tr>";
          cells.forEach((cd, idx) => t += `<td${aligns[idx] ? ` style="text-align:${aligns[idx]}"` : ""}>${inlineWithCode(cd)}</td>`);
          t += "</tr>";
          i++;
        }
        html += t + "</tbody></table>";
        continue;
      }

      // lists
      if (/^\s*[-*+]\s+/.test(line)) { html += listBlock(false); continue; }
      if (/^\s*\d+\.\s+/.test(line)) { html += listBlock(true); continue; }

      // paragraph (collect until blank / block start)
      //
      // A line ending in two or more spaces — or in a lone backslash — is a
      // Markdown hard line break, so it joins the next line with <br> instead of
      // a space. Garoon specs rely on this to keep sentences on their own lines
      // inside one paragraph; trimming each line used to run them all together.
      let para = "";
      let sep = "";
      while (i < lines.length && !/^\s*$/.test(lines[i]) &&
             !/^(#{1,6})\s|^\s*```+|^\s*>|^\s*[-*+]\s|^\s*\d+\.\s/.test(lines[i])) {
        const raw = lines[i];
        para += sep + raw.trim().replace(/(^|[^\\])\\$/, "$1");
        sep = /(?: {2,}|[^\\]\\)$/.test(raw) ? "<br>" : " ";
        i++;
      }
      if (para) html += `<p>${inlineWithCode(para)}</p>`;
    }
    return html;
  }

  globalThis.GKMD = { escapeHtml, inline, inlineWithCode, parseMarkdown, slugify };
})();
