// Fetches a document (.md/.txt/.log) for the Markdown Text Viewer, running IN
// THE PAGE so cookies are sent (private GitHub repos, Kintone attachments) and
// same-origin requests skip CORS. Classic script self-registering on
// globalThis.GKScrape — the same file the popup and the background inject.
//
// The important part: a GitHub ".../blob/<ref>/file.md" link serves an HTML
// PAGE, not markdown. Fetching it verbatim used to feed the page source to the
// parser. GitHub's own "?plain=1" view embeds the file as `rawLines` in a JSON
// island, and unlike /raw/ (which redirects to raw.githubusercontent.com and is
// then blocked by CORS for credentialed requests) it stays on github.com.
(function () {
    "use strict";

    const isGitHubBlob = (u) => /^https:\/\/github\.com\/[^/]+\/[^/]+\/blob\//i.test(u);
    const looksLikeHtml = (t) => /^\s*(?:<!doctype\s+html|<html[\s>])/i.test(t.slice(0, 200));

    // Depth-first search for the rawLines array GitHub embeds in its React payload.
    function findRawLines(obj) {
        let found = null;
        (function walk(o) {
            if (found || !o || typeof o !== "object") return;
            if (Array.isArray(o.rawLines) && o.rawLines.every((x) => typeof x === "string")) { found = o.rawLines; return; }
            for (const k in o) walk(o[k]);
        })(obj);
        return found;
    }

    function rawLinesFromHtml(html) {
        try {
            const doc = new DOMParser().parseFromString(html, "text/html");
            for (const s of doc.querySelectorAll('script[type="application/json"]')) {
                let j;
                try { j = JSON.parse(s.textContent); } catch (e) { continue; }
                const lines = findRawLines(j);
                if (lines) return lines.join("\n");
            }
        } catch (e) {}
        return null;
    }

    // Kintone attachments come from /k/api/record/download.do/... where the URL
    // path does not always carry the real file name — it is in the header.
    function nameFromDisposition(res) {
        const cd = res.headers.get("content-disposition") || "";
        let m = cd.match(/filename\*\s*=\s*UTF-8''([^;]+)/i);
        if (m) { try { return decodeURIComponent(m[1].trim()); } catch (e) { return m[1].trim(); } }
        m = cd.match(/filename\s*=\s*"([^"]+)"/i) || cd.match(/filename\s*=\s*([^;]+)/i);
        return m ? m[1].trim() : null;
    }

    // A cross-origin host that answers with "Access-Control-Allow-Origin: *"
    // (raw.githubusercontent.com, for one) REJECTS credentialed requests, so a
    // link to a public raw file would fail outright. Send cookies first — they
    // are what makes private/authenticated files work — then retry anonymously.
    async function fetchMaybeCredentialed(url) {
        try {
            return await fetch(url, { credentials: "include" });
        } catch (e) {
            const sameOrigin = new URL(url, location.href).origin === location.origin;
            if (sameOrigin) throw e;               // not a CORS-vs-cookies problem
            return await fetch(url, { credentials: "omit" });
        }
    }

    async function fetchDocInPage(url) {
        try {
            // GitHub blob → ask for the plain view and lift the file out of it.
            if (isGitHubBlob(url)) {
                const plain = url.split("#")[0].replace(/([?&])plain=\d/, "$1") + (url.includes("?") ? "&" : "?") + "plain=1";
                const res = await fetchMaybeCredentialed(plain);
                if (res.ok) {
                    const body = await res.text();
                    const raw = rawLinesFromHtml(body);
                    if (raw != null) return { ok: true, text: raw, name: nameFromDisposition(res) };
                    // Not a blob view after all — fall through to the plain fetch.
                }
            }

            const res = await fetchMaybeCredentialed(url);
            if (!res.ok) return { ok: false, status: res.status, error: "HTTP " + res.status };
            const text = await res.text();
            const name = nameFromDisposition(res);

            // Any host may answer a ".md" link with an HTML page; if that page
            // happens to embed the file (GitHub), use it instead of the markup.
            if (looksLikeHtml(text)) {
                const raw = rawLinesFromHtml(text);
                if (raw != null) return { ok: true, text: raw, name };
                return { ok: true, text, name, warning: "the server returned an HTML page, not a text file" };
            }
            return { ok: true, text, name };
        } catch (e) {
            return { ok: false, error: String((e && e.message) || e) };
        }
    }

    (globalThis.GKScrape = globalThis.GKScrape || {}).fetchDocInPage = fetchDocInPage;
})();
