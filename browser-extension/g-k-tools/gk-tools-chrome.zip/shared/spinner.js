// Shared loading spinner overlay — used by tools/md-viewer.js (viewer page) and
// tools/git-md-viewer.js (injected as a content script together with this file).
// Classic script registering globalThis.GKSpin (same pattern as GKMD/GKScrape).
(function () {
    "use strict";

    // Keep the overlay up at least this long — instant loads (local file read,
    // storage handoff) would otherwise flash it for an imperceptible moment.
    const MIN_VISIBLE_MS = 500;
    let shownAt = 0;

    function show(label) {
        document.getElementById("gk-spin")?.remove(); // replace immediately
        shownAt = Date.now();
        const dark = matchMedia("(prefers-color-scheme: dark)").matches;
        const wrap = document.createElement("div");
        wrap.id = "gk-spin";
        wrap.setAttribute("style",
            "position:fixed;inset:0;z-index:2147483646;background:rgba(0,0,0,.45);" +
            "display:flex;align-items:center;justify-content:center;font:14px system-ui");
        const st = document.createElement("style");
        st.textContent = "@keyframes gk-spin-rot{to{transform:rotate(360deg)}}";
        const card = document.createElement("div");
        card.setAttribute("style",
            "display:flex;align-items:center;gap:12px;padding:16px 22px;border-radius:12px;" +
            "box-shadow:0 12px 40px rgba(0,0,0,.4);background:" + (dark ? "#161b22" : "#fff") +
            ";color:" + (dark ? "#e6edf3" : "#1f2328"));
        const ring = document.createElement("div");
        ring.setAttribute("style",
            "width:20px;height:20px;border:3px solid rgba(31,111,235,.25);border-top-color:#1f6feb;" +
            "border-radius:50%;animation:gk-spin-rot .8s linear infinite;flex:0 0 auto");
        const text = document.createElement("span");
        text.setAttribute("style", "font-weight:600");
        text.textContent = label || "Loading…";
        card.appendChild(ring);
        card.appendChild(text);
        wrap.appendChild(st);
        wrap.appendChild(card);
        document.body.appendChild(wrap);
    }

    function hide() {
        const el = document.getElementById("gk-spin");
        if (!el) return;
        const left = MIN_VISIBLE_MS - (Date.now() - shownAt);
        if (left > 0) setTimeout(() => el.remove(), left);
        else el.remove();
    }

    globalThis.GKSpin = { show, hide };
})();
