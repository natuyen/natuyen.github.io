import { api, callSharedScraper, copyFromActiveTab, openExtensionPage, registerHandlers, runFileOnActiveTab, setStatus } from './shared/index.js';

// Scrapers are classic scripts loaded by popup.html BEFORE this module; they
// self-register on globalThis.GKScrape (same files the background injects).
const { scrapePBIRecords, scrapeScheduleComments, scrapeScheduleSprint } = globalThis.GKScrape;

// Show the real version from the manifest (avoids drift with a hard-coded label).
const versionEl = document.getElementById('version');
if (versionEl && api?.runtime?.getManifest) versionEl.textContent = 'v' + api.runtime.getManifest().version;

// About: toggle the author info panel; version comes from the manifest too.
document.addEventListener('DOMContentLoaded', () => {
    const btn = document.getElementById('aboutBtn');
    const panel = document.getElementById('aboutPanel');
    const ver = document.getElementById('aboutVersion');
    if (!btn || !panel) return;
    if (ver && api?.runtime?.getManifest) ver.textContent = 'v' + api.runtime.getManifest().version;
    btn.onclick = () => { panel.hidden = !panel.hidden; };
});

registerHandlers({
    // kintone: copy the record list, columns taken from the popup input.
    copyPBI: () => copyFromActiveTab(scrapePBIRecords, {
        args: [(document.getElementById('pbiColumns')?.value || 'Key,Summary').trim()],
        loading: 'Reading data…',
        success: d => `Copied ${d.rows} rows to clipboard ✓`,
    }),

    // Garoon: copy the schedule comments.
    copyScheduleComment: () => copyFromActiveTab(scrapeScheduleComments, {
        loading: 'Reading comments…',
        success: d => `Copied ${d.count} comments to clipboard ✓`,
    }),

    // Garoon: copy schedule titles grouped by day (sprint).
    copyScheduleSprint: () => copyFromActiveTab(scrapeScheduleSprint, {
        loading: 'Reading schedule…',
        success: d => `Copied ${d.count} events to clipboard ✓`,
    }),

    // Tools: open the Markdown Text Viewer. Hand it the doc links found on the
    // active tab (plus that tab's id, so it can fetch them in the page's own
    // origin) — the viewer then shows a file picker instead of an empty page.
    openMarkdownViewer: async () => {
        try {
            // Injected as a FILE (not a serialized func): the scraper is PR-aware
            // and uses helpers from its own module scope.
            const { tabId, result } = await callSharedScraper('shared/doclinks.js', 'collectDocLinks');
            const links = (result && result.links) || [];
            if (links.length) {
                await api.storage.local.set({ gkMdPayload: { links, tabId } });
                await openExtensionPage('tools/md-viewer.html?src=local');
                window.close();
                return;
            }
        } catch (e) { /* not a scriptable page (e.g. about:) — open empty */ }
        await openExtensionPage('tools/md-viewer.html');
        window.close();
    },

    // Tools: render the .md diff of the current GitHub PR (active tab must be
    // a Files-changed page). Injected as a content script; closes the popup so
    // the overlay is immediately visible.
    gitMdViewer: async () => {
        try {
            const r = await runFileOnActiveTab(
                ['shared/markdown.js', 'shared/spinner.js', 'tools/git-md-viewer.js'], // shared libs first
                /^https:\/\/github\.com\/[^/]+\/[^/]+\/pull\/\d+\/(changes|files)([/?#]|$)/
            );
            if (!r.ok) {
                setStatus(r.error === 'wrong-page'
                    ? 'Open a GitHub PR "Files changed" page (…/pull/<n>/changes) first.'
                    : r.error, 'err');
                return;
            }
            window.close();
        } catch (error) {
            setStatus('Error: ' + (error?.message || error), 'err');
        }
    },
});
